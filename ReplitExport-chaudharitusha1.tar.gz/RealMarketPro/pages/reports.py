import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from collections import Counter
from datetime import datetime, timedelta

# Page configuration
st.set_page_config(
    page_title="Reports | Plant Disease Classifier",
    page_icon="🌿",
    layout="wide",
)

st.title("Analysis Reports")
st.markdown("View statistics and trends from your plant disease analyses.")

# Initialize session state if needed
if 'history' not in st.session_state:
    st.session_state.history = []

def generate_reports():
    if not st.session_state.history:
        st.info("No analysis data available. Upload and analyze plant images to generate reports.")
        return
    
    # Create a DataFrame from history for analysis
    history_data = []
    for entry in st.session_state.history:
        # Parse timestamp to datetime object
        timestamp = datetime.strptime(entry["timestamp"], "%Y-%m-%d %H:%M:%S")
        
        history_data.append({
            "timestamp": timestamp,
            "date": timestamp.date(),
            "prediction": entry["prediction"],
            "confidence": entry["confidence"],
            "filename": entry["filename"]
        })
    
    df = pd.DataFrame(history_data)
    
    # Date range filter
    st.subheader("Date Range Filter")
    
    # Get min and max dates from the history
    min_date = df["date"].min()
    max_date = df["date"].max()
    
    # If we have at least one week of data, default to the last week
    default_start = max_date - timedelta(days=7) if (max_date - min_date).days >= 7 else min_date
    
    col1, col2 = st.columns(2)
    with col1:
        start_date = st.date_input("Start Date", default_start, min_value=min_date, max_value=max_date)
    with col2:
        end_date = st.date_input("End Date", max_date, min_value=min_date, max_value=max_date)
    
    # Filter data based on date range
    filtered_df = df[(df["date"] >= start_date) & (df["date"] <= end_date)]
    
    if filtered_df.empty:
        st.warning("No data available for the selected date range.")
        return
    
    # Display summary statistics
    st.subheader("Summary Statistics")
    
    total_analyses = len(filtered_df)
    unique_diseases = filtered_df["prediction"].nunique()
    avg_confidence = filtered_df["confidence"].mean()
    
    col1, col2, col3 = st.columns(3)
    col1.metric("Total Analyses", total_analyses)
    col2.metric("Unique Diseases Detected", unique_diseases)
    col3.metric("Average Confidence", f"{avg_confidence:.2%}")
    
    # Disease distribution
    st.subheader("Disease Distribution")
    
    disease_counts = filtered_df["prediction"].value_counts()
    
    # Bar chart for disease distribution
    fig, ax = plt.subplots(figsize=(10, 6))
    disease_counts.plot(kind="bar", ax=ax)
    ax.set_title("Count of Detected Diseases")
    ax.set_xlabel("Disease")
    ax.set_ylabel("Count")
    plt.xticks(rotation=45, ha="right")
    plt.tight_layout()
    st.pyplot(fig)
    
    # Confidence distribution
    st.subheader("Confidence Distribution")
    
    # Histogram for confidence scores
    fig, ax = plt.subplots(figsize=(10, 6))
    bins = np.linspace(0, 1, 11)  # 10 bins from 0 to 1
    filtered_df["confidence"].hist(ax=ax, bins=bins)
    ax.set_title("Distribution of Confidence Scores")
    ax.set_xlabel("Confidence Score")
    ax.set_ylabel("Count")
    plt.tight_layout()
    st.pyplot(fig)
    
    # Time-based analysis (if enough data points)
    if len(filtered_df) > 1:
        st.subheader("Trend Analysis")
        
        # Group by date and count analyses per day
        daily_counts = filtered_df.groupby("date").size()
        
        # Line chart for daily analysis counts
        fig, ax = plt.subplots(figsize=(10, 6))
        daily_counts.plot(kind="line", marker="o", ax=ax)
        ax.set_title("Daily Analysis Count")
        ax.set_xlabel("Date")
        ax.set_ylabel("Number of Analyses")
        plt.tight_layout()
        st.pyplot(fig)
    
    # Top detected diseases
    st.subheader("Top Detected Diseases")
    
    top_diseases = filtered_df["prediction"].value_counts().reset_index()
    top_diseases.columns = ["Disease", "Count"]
    
    # Calculate percentage
    top_diseases["Percentage"] = (top_diseases["Count"] / top_diseases["Count"].sum() * 100).round(2)
    top_diseases["Percentage"] = top_diseases["Percentage"].astype(str) + '%'
    
    st.table(top_diseases)
    
    # Disease by confidence
    st.subheader("Disease by Average Confidence")
    
    disease_confidence = filtered_df.groupby("prediction")["confidence"].mean().reset_index()
    disease_confidence.columns = ["Disease", "Average Confidence"]
    disease_confidence["Average Confidence"] = (disease_confidence["Average Confidence"] * 100).round(2).astype(str) + '%'
    
    st.table(disease_confidence)
    
    # Allow downloading the report
    st.subheader("Download Report")
    
    # Create a comprehensive report dataframe
    report_data = {
        "Report Period": [f"{start_date} to {end_date}"],
        "Total Analyses": [total_analyses],
        "Unique Diseases": [unique_diseases],
        "Average Confidence": [f"{avg_confidence:.2%}"],
        "Most Common Disease": [disease_counts.index[0] if not disease_counts.empty else "N/A"],
        "Generated On": [datetime.now().strftime("%Y-%m-%d %H:%M:%S")]
    }
    
    report_df = pd.DataFrame(report_data)
    csv = report_df.to_csv(index=False)
    
    st.download_button(
        label="Download Summary Report",
        data=csv,
        file_name=f"plant_disease_report_{start_date}_to_{end_date}.csv",
        mime='text/csv',
    )

# Sidebar
st.sidebar.title("Analysis Reports")
st.sidebar.info("""
This page provides statistical reports and visualizations based on your plant disease analyses.
Use the date range filter to focus on specific time periods.
""")

# Main content
generate_reports()
