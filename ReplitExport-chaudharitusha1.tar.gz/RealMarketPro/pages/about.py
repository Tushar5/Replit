import streamlit as st

# Page configuration
st.set_page_config(
    page_title="About | Plant Disease Classifier",
    page_icon="🌿",
    layout="wide",
)

st.title("About Plant Disease Classifier")

st.markdown("""
## Project Overview

The Plant Disease Classifier is an AI-powered tool designed to help agricultural professionals, 
gardeners, and plant enthusiasts identify plant diseases quickly and accurately. By leveraging 
machine learning technology, our application can analyze images of plant leaves and identify 
various diseases that may be affecting plant health.

## How It Works

1. **Image Upload**: Users upload images of plant leaves showing symptoms of disease.
2. **AI Analysis**: Our advanced neural network analyzes the image patterns.
3. **Disease Identification**: The system identifies potential diseases based on visual characteristics.
4. **Recommendations**: Users receive information about the disease and treatment options.

## Technology

This application is built using:

- **Streamlit**: For the interactive web interface
- **TensorFlow**: For the machine learning capabilities
- **Python**: As the core programming language
- **PIL/Pillow**: For image processing
- **Pandas**: For data management
- **Matplotlib**: For data visualization

## Benefits

- **Time-Saving**: Get instant disease identification without waiting for lab results
- **Educational**: Learn about various plant diseases and their treatments
- **Preventative**: Catch diseases early before they spread throughout your garden or crops
- **Accessible**: Available anytime, anywhere with internet access

## Limitations

While our system is highly accurate, it has certain limitations:

- Image quality significantly affects analysis accuracy
- Some diseases may have similar visual symptoms
- The system may not recognize very rare plant diseases
- Environmental factors (lighting, etc.) can impact results

## Future Development

We are continuously improving our application with:

- Support for more plant species and disease types
- Enhanced accuracy through larger training datasets
- Mobile application development
- Integration with other agricultural management tools
""")

# Display contact information
st.subheader("Contact Information")
st.markdown("""
For questions, feedback, or support, please contact:

📧 support@plantdiseaseclassifier.com  
🌐 www.plantdiseaseclassifier.com
""")

# Add disclaimer
st.sidebar.title("Disclaimer")
st.sidebar.info("""
This tool is designed to assist with plant disease identification but should not 
replace professional consultation when addressing serious agricultural issues. 
The accuracy of results depends on image quality and proper use of the application.
""")
