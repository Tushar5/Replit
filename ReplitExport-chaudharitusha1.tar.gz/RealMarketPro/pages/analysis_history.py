import streamlit as st
from PIL import Image
import io
import pandas as pd
import json

# Import database utilities
from utils.db_utils import (
    get_all_analyses, 
    get_analyses_by_prediction, 
    clear_all_analyses, 
    delete_analysis
)

# Page configuration
st.set_page_config(
    page_title="Analysis History | Plant Disease Classifier",
    page_icon="🌿",
    layout="wide",
)

st.title("Analysis History")
st.markdown("View and manage your previous plant disease analyses.")

# Function to display history
def display_history():
    try:
        # Fetch all analyses from the database
        analyses = get_all_analyses()
        
        if not analyses:
            st.info("No analysis history found in the database. Upload and analyze plant images to see your history here.")
            return
        
        # Create dataframe from history for display
        history_data = []
        for i, analysis in enumerate(analyses):
            history_data.append({
                "ID": analysis.id,
                "Timestamp": analysis.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                "Filename": analysis.filename,
                "Prediction": analysis.prediction,
                "Confidence": f"{analysis.confidence:.2%}"
            })
        
        history_df = pd.DataFrame(history_data)
        
        # Add a filter for disease type
        unique_diseases = sorted(list(set(analysis.prediction for analysis in analyses)))
        disease_filter = st.multiselect("Filter by disease type:", unique_diseases)
        
        if disease_filter:
            filtered_df = history_df[history_df["Prediction"].isin(disease_filter)]
        else:
            filtered_df = history_df
        
        # Display the filtered dataframe
        st.dataframe(filtered_df, use_container_width=True)
        
        # Option to clear history
        col1, col2 = st.columns(2)
        with col1:
            if st.button("Clear All History"):
                clear_confirmation = st.checkbox("Confirm: Delete all analysis history from database?")
                if clear_confirmation:
                    deleted_count = clear_all_analyses()
                    st.success(f"History cleared successfully! {deleted_count} records deleted.")
                    st.rerun()
        
        with col2:
            # Option to delete individual record
            delete_id = st.number_input("Enter Analysis ID to delete:", min_value=1, step=1)
            if st.button("Delete Selected Analysis"):
                delete_confirmation = st.checkbox("Confirm deletion of analysis ID " + str(delete_id))
                if delete_confirmation:
                    if delete_analysis(delete_id):
                        st.success(f"Analysis ID {delete_id} deleted successfully!")
                        st.rerun()
                    else:
                        st.error(f"Failed to delete analysis ID {delete_id}. Analysis not found.")
        
        # Display gallery of analyzed images
        st.subheader("Image Gallery")
        
        # Determine which analyses to display based on the filter
        if disease_filter:
            # Need to refetch filtered analyses
            display_analyses = []
            for disease in disease_filter:
                display_analyses.extend(get_analyses_by_prediction(disease))
        else:
            display_analyses = analyses
        
        # Display images in a grid
        cols = st.columns(3)
        for i, analysis in enumerate(display_analyses):
            col_idx = i % 3
            with cols[col_idx]:
                if analysis.image_data:
                    try:
                        img = Image.open(io.BytesIO(analysis.image_data))
                        st.image(img, caption=f"{analysis.prediction} ({analysis.confidence:.2%})")
                        st.text(f"ID: {analysis.id}")
                        st.text(f"Analyzed: {analysis.timestamp.strftime('%Y-%m-%d %H:%M:%S')}")
                        st.text(f"File: {analysis.filename}")
                        
                        # Parse recommendations JSON
                        recommendations = []
                        if analysis.recommendations:
                            try:
                                recommendations = json.loads(analysis.recommendations)
                            except:
                                pass
                        
                        # Allow downloading individual analysis reports
                        report_data = {
                            "Analysis ID": [analysis.id],
                            "Analysis Time": [analysis.timestamp.strftime("%Y-%m-%d %H:%M:%S")],
                            "Image Name": [analysis.filename],
                            "Detected Disease": [analysis.prediction],
                            "Confidence": [f"{analysis.confidence:.2%}"],
                            "Recommendations": [", ".join(recommendations)]
                        }
                        
                        report_df = pd.DataFrame(report_data)
                        csv = report_df.to_csv(index=False)
                        st.download_button(
                            label="Download Report",
                            data=csv,
                            file_name=f"analysis_{analysis.id}.csv",
                            mime='text/csv',
                            key=f"download_{analysis.id}"
                        )
                        st.markdown("---")
                    except Exception as e:
                        st.error(f"Error displaying image: {str(e)}")
    except Exception as e:
        st.error(f"Error retrieving analysis history: {str(e)}")
        
        # Fallback to session state if database fails
        if 'history' in st.session_state and st.session_state.history:
            st.warning("Database error. Displaying analyses from current session only.")
            
            # Create dataframe from history for display
            history_data = []
            for i, entry in enumerate(st.session_state.history):
                history_data.append({
                    "ID": i+1,
                    "Timestamp": entry["timestamp"],
                    "Filename": entry["filename"],
                    "Prediction": entry["prediction"],
                    "Confidence": f"{entry['confidence']:.2%}"
                })
            
            if history_data:
                st.dataframe(pd.DataFrame(history_data), use_container_width=True)

# Function to export all history
def export_history():
    try:
        # Fetch all analyses from the database
        analyses = get_all_analyses()
        
        if not analyses:
            st.warning("No history to export.")
            return
        
        # Create dataframe from all history
        export_data = []
        for analysis in analyses:
            # Parse recommendations JSON
            recommendations = []
            if analysis.recommendations:
                try:
                    recommendations = json.loads(analysis.recommendations)
                except:
                    pass
                
            export_data.append({
                "ID": analysis.id,
                "Timestamp": analysis.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
                "Filename": analysis.filename,
                "Prediction": analysis.prediction,
                "Confidence": f"{analysis.confidence:.2%}",
                "Recommendations": ", ".join(recommendations)
            })
        
        export_df = pd.DataFrame(export_data)
        csv = export_df.to_csv(index=False)
        
        st.download_button(
            label="Export Complete History as CSV",
            data=csv,
            file_name="plant_disease_analysis_history.csv",
            mime='text/csv',
            key="export_all"
        )
    except Exception as e:
        st.error(f"Error exporting analysis history: {str(e)}")
        
        # Fallback to session state if database fails
        if 'history' in st.session_state and st.session_state.history:
            st.warning("Database error. Exporting analyses from current session only.")
            
            # Create dataframe from session history
            export_data = []
            for i, entry in enumerate(st.session_state.history):
                export_data.append({
                    "ID": i+1,
                    "Timestamp": entry["timestamp"],
                    "Filename": entry["filename"],
                    "Prediction": entry["prediction"],
                    "Confidence": f"{entry['confidence']:.2%}"
                })
            
            if export_data:
                export_df = pd.DataFrame(export_data)
                csv = export_df.to_csv(index=False)
                
                st.download_button(
                    label="Export Session History as CSV",
                    data=csv,
                    file_name="plant_disease_session_history.csv",
                    mime='text/csv',
                    key="export_session"
                )

# Sidebar
st.sidebar.title("Analysis History")
st.sidebar.info("""
This page shows your previous plant disease analyses.
You can filter results, view the image gallery, and download reports.
""")

# Main layout
tab1, tab2 = st.tabs(["History Table", "Export Options"])

with tab1:
    display_history()

with tab2:
    st.subheader("Export Options")
    st.markdown("Export your analysis history for record-keeping or further analysis.")
    export_history()
    
    # Additional export options
    st.markdown("### Advanced Export Options")
    st.markdown("Select specific date ranges or disease types for export (coming soon)")
