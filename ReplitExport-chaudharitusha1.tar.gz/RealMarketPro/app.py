import streamlit as st
import pandas as pd
import numpy as np
import io
import os
import json
import matplotlib.pyplot as plt
from datetime import datetime
from PIL import Image, UnidentifiedImageError
from utils.image_utils import preprocess_image, visualize_prediction
from utils.model_utils import load_model, predict_disease

# Page configuration
st.set_page_config(
    page_title="Plant Disease Classifier",
    page_icon="🌿",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Initialize session state variables if they don't exist
if 'history' not in st.session_state:
    st.session_state.history = []

# Import database functions
from utils.db_utils import save_analysis, get_recent_analyses

# Load disease information
@st.cache_data
def load_disease_data():
    try:
        with open("data/plant_diseases.json", "r") as f:
            return json.load(f)
    except FileNotFoundError:
        st.error("Disease information file not found.")
        return {}

disease_data = load_disease_data()

# Load the plant disease classification model
@st.cache_resource
def get_model():
    try:
        model = load_model()
        return model
    except Exception as e:
        st.error(f"Failed to load model: {str(e)}")
        return None

model = get_model()

# Main page content
st.title("🌿 Plant Disease Classifier")
st.markdown("""
Upload an image of a plant leaf to identify potential diseases.
Our AI-powered system will analyze the image and provide information about detected diseases.
""")

# Sidebar for navigation
st.sidebar.title("Navigation")
st.sidebar.info("Use the main page to analyze new images. Visit the other pages for history and reports.")

# File uploader
uploaded_file = st.file_uploader("Choose a plant leaf image...", type=["jpg", "jpeg", "png"])

col1, col2 = st.columns(2)

if uploaded_file is not None:
    try:
        # Read and display the uploaded image
        image_bytes = uploaded_file.getvalue()
        image = Image.open(io.BytesIO(image_bytes))
        
        with col1:
            st.subheader("Uploaded Image")
            st.image(image, caption="Uploaded Plant Image", use_column_width=True)
            
            # Image preprocessing options
            st.subheader("Image Preprocessing")
            apply_preprocessing = st.checkbox("Apply image preprocessing")
            
            if apply_preprocessing:
                preprocessing_options = st.multiselect(
                    "Select preprocessing options:",
                    ["Resize", "Normalize", "Enhance contrast"]
                )
        
        # Analyze button
        if st.button("Analyze Image"):
            if model is None:
                st.error("Model failed to load. Cannot perform analysis.")
            else:
                with st.spinner('Analyzing image...'):
                    # Preprocess the image
                    preprocessed_img = preprocess_image(
                        image, 
                        resize=("Resize" in preprocessing_options if apply_preprocessing else True),
                        normalize=("Normalize" in preprocessing_options if apply_preprocessing else True),
                        enhance=("Enhance contrast" in preprocessing_options if apply_preprocessing else False)
                    )
                    
                    # Make prediction
                    prediction, confidence, class_name = predict_disease(model, preprocessed_img)
                    
                    # Store in history
                    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    history_entry = {
                        "timestamp": timestamp,
                        "filename": uploaded_file.name,
                        "prediction": class_name,
                        "confidence": float(confidence),
                        "image": image_bytes
                    }
                    
                    # Save to session state history
                    st.session_state.history.append(history_entry)
                    
                    # Save to database
                    try:
                        save_analysis(history_entry, disease_data)
                        st.sidebar.success("Analysis saved to database")
                    except Exception as e:
                        st.sidebar.error(f"Failed to save to database: {str(e)}")
                    
                    # Display results
                    with col2:
                        st.subheader("Analysis Results")
                        
                        # Create a progress bar for confidence
                        st.markdown(f"**Detected Disease:** {class_name}")
                        st.progress(confidence)
                        st.markdown(f"**Confidence:** {confidence:.2%}")
                        
                        # Display disease information if available
                        if class_name in disease_data:
                            disease_info = disease_data[class_name]
                            st.markdown("### Disease Information")
                            st.markdown(f"**Description:** {disease_info.get('description', 'No description available')}")
                            st.markdown("#### Treatment Recommendations:")
                            for item in disease_info.get('treatments', ['No treatment information available']):
                                st.markdown(f"- {item}")
                        else:
                            if class_name == "healthy":
                                st.success("No disease detected. The plant appears to be healthy.")
                            else:
                                st.warning("Detailed information for this disease is not available.")
                        
                        # Visualization of prediction
                        st.subheader("Prediction Visualization")
                        fig = visualize_prediction(class_name, confidence)
                        st.pyplot(fig)
                        
                        # Download results option
                        report_data = {
                            "Analysis Time": timestamp,
                            "Image Name": uploaded_file.name,
                            "Detected Disease": class_name,
                            "Confidence": f"{confidence:.2%}",
                            "Recommendations": disease_data.get(class_name, {}).get('treatments', ['Not available'])
                        }
                        
                        report_df = pd.DataFrame([report_data])
                        csv = report_df.to_csv(index=False)
                        st.download_button(
                            label="Download Analysis Report",
                            data=csv,
                            file_name=f"plant_disease_analysis_{timestamp.replace(' ', '_').replace(':', '-')}.csv",
                            mime='text/csv',
                        )

    except UnidentifiedImageError:
        st.error("The uploaded file is not a valid image. Please upload a JPG, JPEG, or PNG file.")
    except Exception as e:
        st.error(f"An error occurred: {str(e)}")
else:
    with col1:
        st.info("Please upload an image to begin analysis.")
    
    # Display sample analysis information
    with col2:
        st.subheader("How It Works")
        st.markdown("""
        1. Upload a clear image of a plant leaf
        2. Select optional preprocessing steps
        3. Click 'Analyze Image'
        4. Review the disease classification and recommendations
        5. Download the analysis report if needed
        
        For best results, ensure the image:
        - Is well-lit and in focus
        - Shows the affected area clearly
        - Has minimal background clutter
        """)

# Display recent analyses
st.subheader("Recent Analyses")

# Fetch from database
try:
    recent_analyses = get_recent_analyses(limit=3)
    
    if recent_analyses:
        recent_cols = st.columns(min(len(recent_analyses), 3))
        
        for i, analysis in enumerate(recent_analyses):
            with recent_cols[i]:
                # Convert binary image data back to PIL Image
                img_data = analysis.image_data
                if img_data:
                    img = Image.open(io.BytesIO(img_data))
                    st.image(img, caption=f"{analysis.prediction} ({analysis.confidence:.2%})", width=150)
                    st.text(analysis.timestamp.strftime("%Y-%m-%d %H:%M:%S"))
    else:
        st.info("No analysis history found in the database. Upload and analyze an image to start.")
except Exception as e:
    st.error(f"Failed to load analysis history: {str(e)}")
    
    # Fall back to session state if database fails
    if st.session_state.history:
        st.warning("Displaying analyses from current session only.")
        
        # Show last 3 analyses
        recent_items = st.session_state.history[-3:]
        recent_items.reverse()  # Most recent first
        
        recent_cols = st.columns(min(len(recent_items), 3))
        
        for i, item in enumerate(recent_items):
            with recent_cols[i]:
                img = Image.open(io.BytesIO(item["image"]))
                st.image(img, caption=f"{item['prediction']} ({item['confidence']:.2%})", width=150)
                st.text(item["timestamp"])
