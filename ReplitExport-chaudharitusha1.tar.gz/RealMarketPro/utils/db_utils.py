import os
import io
import json
import base64
from datetime import datetime
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, LargeBinary, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# Get database URL from environment variable
DATABASE_URL = os.environ.get('DATABASE_URL')

if not DATABASE_URL:
    # Raise a clear error message if the DATABASE_URL is not set
    import sys
    print("Error: DATABASE_URL environment variable is not set. Database functionality will be disabled.")
    DATABASE_URL = "sqlite:///:memory:"  # Fallback to in-memory database for testing

# Create SQLAlchemy engine
engine = create_engine(DATABASE_URL)

# Create base class for declarative models
Base = declarative_base()

class Analysis(Base):
    """Analysis model for storing plant disease analysis results"""
    __tablename__ = 'analyses'
    
    id = Column(Integer, primary_key=True)
    timestamp = Column(DateTime, default=datetime.utcnow)
    filename = Column(String(255))
    prediction = Column(String(100))
    confidence = Column(Float)
    image_data = Column(LargeBinary)
    recommendations = Column(Text)
    
    def to_dict(self):
        """Convert the analysis to a dictionary"""
        return {
            "id": self.id,
            "timestamp": self.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            "filename": self.filename,
            "prediction": self.prediction,
            "confidence": self.confidence,
            "image": self.image_data,
            "recommendations": json.loads(self.recommendations) if self.recommendations else []
        }
    
    @classmethod
    def from_dict(cls, data, disease_data=None):
        """Create an Analysis instance from a dictionary"""
        recommendations = []
        
        # Get recommendations from disease data if available
        if disease_data and data.get("prediction") in disease_data:
            recommendations = disease_data[data["prediction"]].get("treatments", [])
        
        return cls(
            timestamp=datetime.strptime(data["timestamp"], "%Y-%m-%d %H:%M:%S") if isinstance(data["timestamp"], str) else data["timestamp"],
            filename=data["filename"],
            prediction=data["prediction"],
            confidence=float(data["confidence"]) if isinstance(data["confidence"], str) else data["confidence"],
            image_data=data["image"],
            recommendations=json.dumps(recommendations)
        )

# Create tables
Base.metadata.create_all(engine)

# Create a session factory
Session = sessionmaker(bind=engine)

def save_analysis(analysis_data, disease_data=None):
    """
    Save a new analysis record to the database
    
    Args:
        analysis_data: Dictionary with analysis data
        disease_data: Dictionary with disease information
        
    Returns:
        The saved Analysis instance ID
    """
    session = Session()
    try:
        # Create a new Analysis instance
        analysis = Analysis.from_dict(analysis_data, disease_data)
        
        # Add and commit to the database
        session.add(analysis)
        session.commit()
        
        return analysis.id
    except Exception as e:
        session.rollback()
        raise e
    finally:
        session.close()

def get_all_analyses():
    """
    Get all analyses from the database
    
    Returns:
        List of Analysis objects
    """
    session = Session()
    try:
        analyses = session.query(Analysis).order_by(Analysis.timestamp.desc()).all()
        return analyses
    finally:
        session.close()

def get_analysis_by_id(analysis_id):
    """
    Get a specific analysis by ID
    
    Args:
        analysis_id: ID of the analysis to retrieve
        
    Returns:
        Analysis object or None if not found
    """
    session = Session()
    try:
        analysis = session.query(Analysis).filter(Analysis.id == analysis_id).first()
        return analysis
    finally:
        session.close()

def delete_analysis(analysis_id):
    """
    Delete an analysis by ID
    
    Args:
        analysis_id: ID of the analysis to delete
        
    Returns:
        True if successful, False otherwise
    """
    session = Session()
    try:
        analysis = session.query(Analysis).filter(Analysis.id == analysis_id).first()
        if analysis:
            session.delete(analysis)
            session.commit()
            return True
        return False
    except:
        session.rollback()
        return False
    finally:
        session.close()

def clear_all_analyses():
    """
    Delete all analyses from the database
    
    Returns:
        Number of deleted records
    """
    session = Session()
    try:
        count = session.query(Analysis).delete()
        session.commit()
        return count
    except:
        session.rollback()
        return 0
    finally:
        session.close()

def get_analyses_by_prediction(prediction):
    """
    Get analyses by prediction/disease type
    
    Args:
        prediction: The prediction/disease type to filter by
        
    Returns:
        List of Analysis objects
    """
    session = Session()
    try:
        analyses = session.query(Analysis).filter(Analysis.prediction == prediction).order_by(Analysis.timestamp.desc()).all()
        return analyses
    finally:
        session.close()

def get_recent_analyses(limit=5):
    """
    Get the most recent analyses
    
    Args:
        limit: Maximum number of analyses to retrieve
        
    Returns:
        List of Analysis objects
    """
    session = Session()
    try:
        analyses = session.query(Analysis).order_by(Analysis.timestamp.desc()).limit(limit).all()
        return analyses
    finally:
        session.close()