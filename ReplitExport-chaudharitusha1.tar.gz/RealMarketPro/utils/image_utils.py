import numpy as np
import matplotlib.pyplot as plt
from PIL import Image, ImageEnhance
import io

def preprocess_image(image, resize=True, normalize=True, enhance=False, target_size=(224, 224)):
    """
    Preprocess the image for model input
    
    Args:
        image: PIL Image object
        resize: Whether to resize the image
        normalize: Whether to normalize pixel values
        enhance: Whether to enhance contrast
        target_size: Target size for resizing
        
    Returns:
        Preprocessed image as numpy array
    """
    # Make a copy to avoid modifying the original
    img = image.copy()
    
    # Convert to RGB if needed
    if img.mode != 'RGB':
        img = img.convert('RGB')
    
    # Enhance contrast if requested
    if enhance:
        enhancer = ImageEnhance.Contrast(img)
        img = enhancer.enhance(1.5)  # Increase contrast by 50%
    
    # Resize to target size if requested
    if resize:
        img = img.resize(target_size, Image.LANCZOS)
    
    # Convert to numpy array
    img_array = np.array(img)
    
    # Normalize pixel values if requested
    if normalize:
        img_array = img_array / 255.0
    
    # Expand dimensions for model input (batch size of 1)
    img_array = np.expand_dims(img_array, axis=0)
    
    return img_array

def visualize_prediction(class_name, confidence):
    """
    Create a visualization of the prediction
    
    Args:
        class_name: Predicted class name
        confidence: Prediction confidence
        
    Returns:
        Matplotlib figure
    """
    fig, ax = plt.subplots(figsize=(6, 3))
    
    # Create a horizontal bar chart for confidence
    classes = [class_name]
    confidences = [confidence]
    
    y_pos = np.arange(len(classes))
    
    ax.barh(y_pos, confidences, align='center', color='green' if confidence > 0.7 else 'orange')
    ax.set_yticks(y_pos)
    ax.set_yticklabels(classes)
    ax.invert_yaxis()  # Labels read top-to-bottom
    ax.set_xlabel('Confidence Score')
    ax.set_title('Disease Classification Confidence')
    
    # Add confidence percentage as text
    for i, v in enumerate(confidences):
        ax.text(v - 0.1, i, f"{v:.2%}", color='white', fontweight='bold', va='center')
    
    plt.tight_layout()
    return fig

def pil_image_to_byte_array(image):
    """Convert PIL Image to byte array"""
    byte_arr = io.BytesIO()
    image.save(byte_arr, format='PNG')
    return byte_arr.getvalue()

def byte_array_to_pil_image(byte_array):
    """Convert byte array to PIL Image"""
    return Image.open(io.BytesIO(byte_array))
