import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import streamlit as st

def plot_map_data(df):
    """
    Plot drive test data on a map with various metrics.
    
    Args:
        df: DataFrame with drive test data
        
    Returns:
        fig: Plotly figure with map visualization
    """
    # Check if we have location data
    if 'Latitude' not in df.columns or 'Longitude' not in df.columns:
        # Create a figure with a message
        fig = go.Figure()
        fig.add_annotation(
            text="No location data available for map visualization",
            showarrow=False,
            font=dict(size=16)
        )
        fig.update_layout(height=500)
        return fig
    
    # Filter out rows with missing location data
    df_map = df.dropna(subset=['Latitude', 'Longitude']).copy()
    
    if len(df_map) == 0:
        # Create a figure with a message
        fig = go.Figure()
        fig.add_annotation(
            text="No valid location data available for map visualization",
            showarrow=False,
            font=dict(size=16)
        )
        fig.update_layout(height=500)
        return fig
    
    # Define which column to use for coloring the points
    if 'RSRP' in df_map.columns:
        color_column = 'RSRP'
        color_scale = 'RdYlGn'  # Red (poor) to Green (good)
        hover_data = ['RSRP', 'RSRQ', 'SINR'] if all(col in df_map.columns for col in ['RSRQ', 'SINR']) else ['RSRP']
        title = 'RSRP (dBm) Distribution'
        
        # For RSRP, values typically range from -140 (poor) to -70 (good)
        range_color = [-140, -70]
    elif 'SINR' in df_map.columns:
        color_column = 'SINR'
        color_scale = 'RdYlGn'  # Red (poor) to Green (good)
        hover_data = ['SINR']
        title = 'SINR (dB) Distribution'
        
        # For SINR, values typically range from -10 (poor) to 30 (good)
        range_color = [-10, 30]
    elif 'RSRQ' in df_map.columns:
        color_column = 'RSRQ'
        color_scale = 'RdYlGn'  # Red (poor) to Green (good)
        hover_data = ['RSRQ']
        title = 'RSRQ (dB) Distribution'
        
        # For RSRQ, values typically range from -20 (poor) to 0 (good)
        range_color = [-20, 0]
    else:
        # If none of the RF metrics are available, use a dummy column
        df_map['Point'] = 1
        color_column = 'Point'
        color_scale = 'Blues'
        hover_data = []
        title = 'Drive Test Path'
        range_color = None
    
    # Add cell ID to hover data if available
    if 'CellID' in df_map.columns:
        hover_data.append('CellID')
    
    # Add PCI to hover data if available
    if 'PCI' in df_map.columns:
        hover_data.append('PCI')
    
    # Add EARFCN to hover data if available
    if 'EARFCN' in df_map.columns:
        hover_data.append('EARFCN')
    
    # Add event to hover data if available
    if 'Event' in df_map.columns:
        hover_data.append('Event')
    
    # Create the figure
    fig = px.scatter_mapbox(
        df_map,
        lat='Latitude',
        lon='Longitude',
        color=color_column,
        size_max=10,
        zoom=11,
        mapbox_style="carto-positron",
        color_continuous_scale=color_scale,
        range_color=range_color,
        hover_name='Timestamp' if 'Timestamp' in df_map.columns else None,
        hover_data=hover_data,
        title=title,
        opacity=0.7
    )
    
    # Add cell changes if available
    if 'Cell_Change' in df_map.columns:
        cell_changes = df_map[df_map['Cell_Change'] == True]
        if len(cell_changes) > 0:
            fig.add_trace(
                go.Scattermapbox(
                    lat=cell_changes['Latitude'],
                    lon=cell_changes['Longitude'],
                    mode='markers',
                    marker=dict(size=12, color='black', symbol='circle'),
                    name='Cell Change',
                    hoverinfo='text',
                    hovertext=[f"Cell Change at {row['Timestamp']}<br>From: {row['CellID.1'] if 'CellID.1' in row else 'Unknown'}<br>To: {row['CellID']}" 
                               for _, row in cell_changes.iterrows()] if 'Timestamp' in cell_changes.columns else None
                )
            )
    
    # Add handover events if available
    if 'Handover_Event' in df_map.columns:
        handovers = df_map[df_map['Handover_Event'] == True]
        if len(handovers) > 0:
            fig.add_trace(
                go.Scattermapbox(
                    lat=handovers['Latitude'],
                    lon=handovers['Longitude'],
                    mode='markers',
                    marker=dict(size=12, color='blue', symbol='star'),
                    name='Handover',
                    hoverinfo='text',
                    hovertext=[f"Handover at {row['Timestamp']}<br>From: {row['PCI.1'] if 'PCI.1' in row else 'Unknown'}<br>To: {row['PCI']}" 
                               for _, row in handovers.iterrows()] if 'Timestamp' in handovers.columns else None
                )
            )
    
    # Add call drop events if available in the Event column
    if 'Event' in df_map.columns:
        call_drops = df_map[df_map['Event'].str.contains('drop|fail', case=False, na=False)]
        if len(call_drops) > 0:
            fig.add_trace(
                go.Scattermapbox(
                    lat=call_drops['Latitude'],
                    lon=call_drops['Longitude'],
                    mode='markers',
                    marker=dict(size=15, color='red', symbol='x'),
                    name='Call Drop/Failure',
                    hoverinfo='text',
                    hovertext=[f"Event: {row['Event']}<br>Time: {row['Timestamp']}<br>Detail: {row['Event_Detail'] if 'Event_Detail' in row and pd.notna(row['Event_Detail']) else 'N/A'}" 
                               for _, row in call_drops.iterrows()] if 'Timestamp' in call_drops.columns else None
                )
            )
    
    # Layout adjustments
    fig.update_layout(
        height=600,
        margin=dict(l=0, r=0, t=50, b=0),
        legend=dict(
            orientation="h",
            yanchor="bottom",
            y=1.02,
            xanchor="right",
            x=1
        )
    )
    
    return fig

def plot_rsrp_distribution(df):
    """
    Plot the distribution of RSRP values.
    
    Args:
        df: DataFrame with drive test data
        
    Returns:
        fig: Plotly figure with RSRP distribution
    """
    # Check if we have RSRP data
    if 'RSRP' not in df.columns:
        # Create a figure with a message
        fig = go.Figure()
        fig.add_annotation(
            text="No RSRP data available for visualization",
            showarrow=False,
            font=dict(size=16)
        )
        fig.update_layout(height=400)
        return fig
    
    # Filter out rows with missing RSRP data
    df_rsrp = df.dropna(subset=['RSRP']).copy()
    
    if len(df_rsrp) == 0:
        # Create a figure with a message
        fig = go.Figure()
        fig.add_annotation(
            text="No valid RSRP data available for visualization",
            showarrow=False,
            font=dict(size=16)
        )
        fig.update_layout(height=400)
        return fig
    
    # Create RSRP categories for the histogram
    rsrp_bins = [-float('inf'), -120, -110, -100, -90, -80, -70, float('inf')]
    rsrp_labels = ['< -120', '-120 to -110', '-110 to -100', '-100 to -90', '-90 to -80', '-80 to -70', '> -70']
    
    df_rsrp['RSRP_Category'] = pd.cut(df_rsrp['RSRP'], bins=rsrp_bins, labels=rsrp_labels)
    
    # Count samples in each category
    rsrp_counts = df_rsrp['RSRP_Category'].value_counts().sort_index()
    
    # Define colors for each category (red to green)
    colors = ['#d73027', '#f46d43', '#fdae61', '#fee08b', '#d9ef8b', '#a6d96a', '#66bd63']
    
    # Create the figure
    fig = go.Figure()
    
    # Add histogram bars
    fig.add_trace(
        go.Bar(
            x=rsrp_counts.index,
            y=rsrp_counts.values,
            marker_color=colors[:len(rsrp_counts)],
            text=rsrp_counts.values,
            textposition='auto',
            name='RSRP Distribution'
        )
    )
    
    # Add a reference line for the threshold (-105 dBm is a common threshold)
    threshold_category = pd.cut(pd.Series([-105]), bins=rsrp_bins, labels=rsrp_labels)[0]
    
    # Add vertical line or annotation to indicate the threshold
    if threshold_category in rsrp_counts.index:
        threshold_index = list(rsrp_counts.index).index(threshold_category)
        fig.add_shape(
            type="line",
            x0=threshold_category,
            y0=0,
            x1=threshold_category,
            y1=rsrp_counts.max() * 1.1,
            line=dict(
                color="Red",
                width=2,
                dash="dash",
            )
        )
        
        fig.add_annotation(
            x=threshold_category,
            y=rsrp_counts.max() * 1.05,
            text="Threshold: -105 dBm",
            showarrow=False,
            font=dict(color="Red")
        )
    
    # Calculate percentages for each category
    percentages = (rsrp_counts / rsrp_counts.sum() * 100).round(1)
    
    # Add a text annotation with statistics
    stats_text = (
        f"Min: {df_rsrp['RSRP'].min():.2f} dBm<br>"
        f"Max: {df_rsrp['RSRP'].max():.2f} dBm<br>"
        f"Mean: {df_rsrp['RSRP'].mean():.2f} dBm<br>"
        f"Median: {df_rsrp['RSRP'].median():.2f} dBm<br>"
        f"Below -105 dBm: {(df_rsrp['RSRP'] < -105).sum() / len(df_rsrp) * 100:.1f}%"
    )
    
    fig.add_annotation(
        x=0.95,
        y=0.95,
        xref="paper",
        yref="paper",
        text=stats_text,
        showarrow=False,
        align="right",
        bgcolor="rgba(255, 255, 255, 0.8)",
        bordercolor="black",
        borderwidth=1
    )
    
    # Update layout
    fig.update_layout(
        title="RSRP Distribution",
        xaxis_title="RSRP Range (dBm)",
        yaxis_title="Number of Samples",
        height=400,
        bargap=0.1,
        xaxis={'categoryorder':'array', 'categoryarray':rsrp_labels}
    )
    
    return fig

def plot_rsrq_distribution(df):
    """
    Plot the distribution of RSRQ values.
    
    Args:
        df: DataFrame with drive test data
        
    Returns:
        fig: Plotly figure with RSRQ distribution
    """
    # Check if we have RSRQ data
    if 'RSRQ' not in df.columns:
        # Create a figure with a message
        fig = go.Figure()
        fig.add_annotation(
            text="No RSRQ data available for visualization",
            showarrow=False,
            font=dict(size=16)
        )
        fig.update_layout(height=400)
        return fig
    
    # Filter out rows with missing RSRQ data
    df_rsrq = df.dropna(subset=['RSRQ']).copy()
    
    if len(df_rsrq) == 0:
        # Create a figure with a message
        fig = go.Figure()
        fig.add_annotation(
            text="No valid RSRQ data available for visualization",
            showarrow=False,
            font=dict(size=16)
        )
        fig.update_layout(height=400)
        return fig
    
    # Create RSRQ categories for the histogram
    rsrq_bins = [-float('inf'), -20, -18, -15, -12, -10, -8, -5, 0, float('inf')]
    rsrq_labels = ['< -20', '-20 to -18', '-18 to -15', '-15 to -12', '-12 to -10', '-10 to -8', '-8 to -5', '-5 to 0', '> 0']
    
    df_rsrq['RSRQ_Category'] = pd.cut(df_rsrq['RSRQ'], bins=rsrq_bins, labels=rsrq_labels)
    
    # Count samples in each category
    rsrq_counts = df_rsrq['RSRQ_Category'].value_counts().sort_index()
    
    # Define colors for each category (red to green)
    colors = ['#d73027', '#f46d43', '#fdae61', '#fee08b', '#d9ef8b', '#a6d96a', '#66bd63', '#1a9850', '#006837']
    
    # Create the figure
    fig = go.Figure()
    
    # Add histogram bars
    fig.add_trace(
        go.Bar(
            x=rsrq_counts.index,
            y=rsrq_counts.values,
            marker_color=colors[:len(rsrq_counts)],
            text=rsrq_counts.values,
            textposition='auto',
            name='RSRQ Distribution'
        )
    )
    
    # Add a reference line for the threshold (-15 dB is a common threshold)
    threshold_category = pd.cut(pd.Series([-15]), bins=rsrq_bins, labels=rsrq_labels)[0]
    
    # Add vertical line or annotation to indicate the threshold
    if threshold_category in rsrq_counts.index:
        threshold_index = list(rsrq_counts.index).index(threshold_category)
        fig.add_shape(
            type="line",
            x0=threshold_category,
            y0=0,
            x1=threshold_category,
            y1=rsrq_counts.max() * 1.1,
            line=dict(
                color="Red",
                width=2,
                dash="dash",
            )
        )
        
        fig.add_annotation(
            x=threshold_category,
            y=rsrq_counts.max() * 1.05,
            text="Threshold: -15 dB",
            showarrow=False,
            font=dict(color="Red")
        )
    
    # Calculate percentages for each category
    percentages = (rsrq_counts / rsrq_counts.sum() * 100).round(1)
    
    # Add a text annotation with statistics
    stats_text = (
        f"Min: {df_rsrq['RSRQ'].min():.2f} dB<br>"
        f"Max: {df_rsrq['RSRQ'].max():.2f} dB<br>"
        f"Mean: {df_rsrq['RSRQ'].mean():.2f} dB<br>"
        f"Median: {df_rsrq['RSRQ'].median():.2f} dB<br>"
        f"Below -15 dB: {(df_rsrq['RSRQ'] < -15).sum() / len(df_rsrq) * 100:.1f}%"
    )
    
    fig.add_annotation(
        x=0.95,
        y=0.95,
        xref="paper",
        yref="paper",
        text=stats_text,
        showarrow=False,
        align="right",
        bgcolor="rgba(255, 255, 255, 0.8)",
        bordercolor="black",
        borderwidth=1
    )
    
    # Update layout
    fig.update_layout(
        title="RSRQ Distribution",
        xaxis_title="RSRQ Range (dB)",
        yaxis_title="Number of Samples",
        height=400,
        bargap=0.1,
        xaxis={'categoryorder':'array', 'categoryarray':rsrq_labels}
    )
    
    return fig

def plot_sinr_distribution(df):
    """
    Plot the distribution of SINR values.
    
    Args:
        df: DataFrame with drive test data
        
    Returns:
        fig: Plotly figure with SINR distribution
    """
    # Check if we have SINR data
    if 'SINR' not in df.columns:
        # Create a figure with a message
        fig = go.Figure()
        fig.add_annotation(
            text="No SINR data available for visualization",
            showarrow=False,
            font=dict(size=16)
        )
        fig.update_layout(height=400)
        return fig
    
    # Filter out rows with missing SINR data
    df_sinr = df.dropna(subset=['SINR']).copy()
    
    if len(df_sinr) == 0:
        # Create a figure with a message
        fig = go.Figure()
        fig.add_annotation(
            text="No valid SINR data available for visualization",
            showarrow=False,
            font=dict(size=16)
        )
        fig.update_layout(height=400)
        return fig
    
    # Create SINR categories for the histogram
    sinr_bins = [-float('inf'), -5, 0, 5, 10, 15, 20, 25, 30, float('inf')]
    sinr_labels = ['< -5', '-5 to 0', '0 to 5', '5 to 10', '10 to 15', '15 to 20', '20 to 25', '25 to 30', '> 30']
    
    df_sinr['SINR_Category'] = pd.cut(df_sinr['SINR'], bins=sinr_bins, labels=sinr_labels)
    
    # Count samples in each category
    sinr_counts = df_sinr['SINR_Category'].value_counts().sort_index()
    
    # Define colors for each category (red to green)
    colors = ['#d73027', '#f46d43', '#fdae61', '#fee08b', '#d9ef8b', '#a6d96a', '#66bd63', '#1a9850', '#006837']
    
    # Create the figure
    fig = go.Figure()
    
    # Add histogram bars
    fig.add_trace(
        go.Bar(
            x=sinr_counts.index,
            y=sinr_counts.values,
            marker_color=colors[:len(sinr_counts)],
            text=sinr_counts.values,
            textposition='auto',
            name='SINR Distribution'
        )
    )
    
    # Add a reference line for the threshold (5 dB is a common threshold)
    threshold_category = pd.cut(pd.Series([5]), bins=sinr_bins, labels=sinr_labels)[0]
    
    # Add vertical line or annotation to indicate the threshold
    if threshold_category in sinr_counts.index:
        threshold_index = list(sinr_counts.index).index(threshold_category)
        fig.add_shape(
            type="line",
            x0=threshold_category,
            y0=0,
            x1=threshold_category,
            y1=sinr_counts.max() * 1.1,
            line=dict(
                color="Red",
                width=2,
                dash="dash",
            )
        )
        
        fig.add_annotation(
            x=threshold_category,
            y=sinr_counts.max() * 1.05,
            text="Threshold: 5 dB",
            showarrow=False,
            font=dict(color="Red")
        )
    
    # Calculate percentages for each category
    percentages = (sinr_counts / sinr_counts.sum() * 100).round(1)
    
    # Add a text annotation with statistics
    stats_text = (
        f"Min: {df_sinr['SINR'].min():.2f} dB<br>"
        f"Max: {df_sinr['SINR'].max():.2f} dB<br>"
        f"Mean: {df_sinr['SINR'].mean():.2f} dB<br>"
        f"Median: {df_sinr['SINR'].median():.2f} dB<br>"
        f"Below 5 dB: {(df_sinr['SINR'] < 5).sum() / len(df_sinr) * 100:.1f}%"
    )
    
    fig.add_annotation(
        x=0.95,
        y=0.95,
        xref="paper",
        yref="paper",
        text=stats_text,
        showarrow=False,
        align="right",
        bgcolor="rgba(255, 255, 255, 0.8)",
        bordercolor="black",
        borderwidth=1
    )
    
    # Update layout
    fig.update_layout(
        title="SINR Distribution",
        xaxis_title="SINR Range (dB)",
        yaxis_title="Number of Samples",
        height=400,
        bargap=0.1,
        xaxis={'categoryorder':'array', 'categoryarray':sinr_labels}
    )
    
    return fig

def plot_handover_events(df, handover_results):
    """
    Plot handover events and their success/failure.
    
    Args:
        df: DataFrame with drive test data
        handover_results: Dictionary with handover analysis results
        
    Returns:
        fig: Plotly figure with handover events visualization
    """
    # Create a basic figure
    fig = make_subplots(rows=1, cols=2, 
                       specs=[[{"type": "domain"}, {"type": "bar"}]],
                       column_widths=[0.4, 0.6],
                       subplot_titles=["Handover Success Rate", "Handover Failure Causes"])
    
    # If there are no handovers, return a message
    if handover_results['total_handovers'] == 0:
        fig = go.Figure()
        fig.add_annotation(
            text="No handover events detected in the dataset",
            showarrow=False,
            font=dict(size=16)
        )
        fig.update_layout(height=400)
        return fig
    
    # Add pie chart for handover success rate
    labels = ['Successful', 'Failed']
    values = [handover_results['successful_handovers'], handover_results['failed_handovers']]
    colors = ['#66bd63', '#d73027'] if handover_results['failed_handovers'] > 0 else ['#66bd63']
    
    fig.add_trace(
        go.Pie(
            labels=labels,
            values=values,
            hole=0.6,
            marker_colors=colors,
            textinfo='percent+label',
            pull=[0, 0.1] if handover_results['failed_handovers'] > 0 else [0],
            name="Handover Success Rate"
        ),
        row=1, col=1
    )
    
    # Add an annotation in the center of the pie chart
    fig.add_annotation(
        x=0.20,
        y=0.5,
        text=f"{handover_results['handover_success_rate']:.1f}%<br>Success Rate",
        showarrow=False,
        font=dict(size=16),
        xref="paper",
        yref="paper"
    )
    
    # Add bar chart for failure causes
    failure_causes = handover_results.get('failure_causes', {})
    
    if failure_causes:
        causes = list(failure_causes.keys())
        counts = list(failure_causes.values())
        
        fig.add_trace(
            go.Bar(
                x=causes,
                y=counts,
                marker_color='#d73027',
                text=counts,
                textposition='auto',
                name="Failure Causes"
            ),
            row=1, col=2
        )
    else:
        # If no failure causes, add a message
        fig.add_annotation(
            x=0.75,
            y=0.5,
            text="No handover failures detected",
            showarrow=False,
            font=dict(size=14),
            xref="paper",
            yref="paper"
        )
    
    # Update layout
    fig.update_layout(
        title_text="Handover Analysis",
        height=400,
        showlegend=False
    )
    
    # Update the yaxis of the second subplot
    fig.update_yaxes(title_text="Number of Failures", row=1, col=2)
    
    return fig

def plot_throughput_analysis(df, throughput_results):
    """
    Plot throughput analysis results.
    
    Args:
        df: DataFrame with drive test data
        throughput_results: Dictionary with throughput analysis results
        
    Returns:
        fig: Plotly figure with throughput analysis visualization
    """
    # Check if we have throughput data
    if ('Throughput_DL' not in df.columns or df['Throughput_DL'].isna().all()) and \
       ('Throughput_UL' not in df.columns or df['Throughput_UL'].isna().all()):
        # Create a figure with a message
        fig = go.Figure()
        fig.add_annotation(
            text="No throughput data available for visualization",
            showarrow=False,
            font=dict(size=16)
        )
        fig.update_layout(height=500)
        return fig
    
    # Create a figure with subplots
    fig = make_subplots(rows=2, cols=1, 
                       subplot_titles=["Downlink Throughput Distribution", "Uplink Throughput Distribution"],
                       vertical_spacing=0.2)
    
    # Prepare data for DL throughput
    if 'Throughput_DL' in df.columns and not df['Throughput_DL'].isna().all():
        df_dl = df.dropna(subset=['Throughput_DL']).copy()
        
        # Create throughput categories
        dl_bins = [0, 1, 5, 10, 20, 50, 100, float('inf')]
        dl_labels = ['0-1', '1-5', '5-10', '10-20', '20-50', '50-100', '>100']
        
        df_dl['DL_Category'] = pd.cut(df_dl['Throughput_DL'], bins=dl_bins, labels=dl_labels)
        
        # Count samples in each category
        dl_counts = df_dl['DL_Category'].value_counts().sort_index()
        
        # Add bar chart for DL throughput
        fig.add_trace(
            go.Bar(
                x=dl_counts.index,
                y=dl_counts.values,
                marker_color='#1f77b4',
                text=dl_counts.values,
                textposition='auto',
                name="DL Throughput"
            ),
            row=1, col=1
        )
        
        # Add a text annotation with statistics
        stats_text = (
            f"Avg DL: {df_dl['Throughput_DL'].mean():.2f} Mbps<br>"
            f"Max DL: {df_dl['Throughput_DL'].max():.2f} Mbps<br>"
            f"Below 5 Mbps: {(df_dl['Throughput_DL'] < 5).sum() / len(df_dl) * 100:.1f}%"
        )
        
        fig.add_annotation(
            x=0.95,
            y=0.95,
            xref="x1",
            yref="y1",
            text=stats_text,
            showarrow=False,
            align="right",
            bgcolor="rgba(255, 255, 255, 0.8)",
            bordercolor="black",
            borderwidth=1
        )
        
        # Update y-axis
        fig.update_yaxes(title_text="Number of Samples", row=1, col=1)
    else:
        # Add a message if no DL data
        fig.add_annotation(
            x=0.5,
            y=0.75,
            text="No downlink throughput data available",
            showarrow=False,
            font=dict(size=14),
            xref="paper",
            yref="paper"
        )
    
    # Prepare data for UL throughput
    if 'Throughput_UL' in df.columns and not df['Throughput_UL'].isna().all():
        df_ul = df.dropna(subset=['Throughput_UL']).copy()
        
        # Create throughput categories
        ul_bins = [0, 0.5, 1, 2, 5, 10, 20, float('inf')]
        ul_labels = ['0-0.5', '0.5-1', '1-2', '2-5', '5-10', '10-20', '>20']
        
        df_ul['UL_Category'] = pd.cut(df_ul['Throughput_UL'], bins=ul_bins, labels=ul_labels)
        
        # Count samples in each category
        ul_counts = df_ul['UL_Category'].value_counts().sort_index()
        
        # Add bar chart for UL throughput
        fig.add_trace(
            go.Bar(
                x=ul_counts.index,
                y=ul_counts.values,
                marker_color='#ff7f0e',
                text=ul_counts.values,
                textposition='auto',
                name="UL Throughput"
            ),
            row=2, col=1
        )
        
        # Add a text annotation with statistics
        stats_text = (
            f"Avg UL: {df_ul['Throughput_UL'].mean():.2f} Mbps<br>"
            f"Max UL: {df_ul['Throughput_UL'].max():.2f} Mbps<br>"
            f"Below 1 Mbps: {(df_ul['Throughput_UL'] < 1).sum() / len(df_ul) * 100:.1f}%"
        )
        
        fig.add_annotation(
            x=0.95,
            y=0.95,
            xref="x2",
            yref="y2",
            text=stats_text,
            showarrow=False,
            align="right",
            bgcolor="rgba(255, 255, 255, 0.8)",
            bordercolor="black",
            borderwidth=1
        )
        
        # Update y-axis and x-axis
        fig.update_yaxes(title_text="Number of Samples", row=2, col=1)
        fig.update_xaxes(title_text="Throughput (Mbps)", row=2, col=1)
    else:
        # Add a message if no UL data
        fig.add_annotation(
            x=0.5,
            y=0.25,
            text="No uplink throughput data available",
            showarrow=False,
            font=dict(size=14),
            xref="paper",
            yref="paper"
        )
    
    # Update layout
    fig.update_layout(
        title_text="Throughput Analysis",
        height=600,
        showlegend=False
    )
    
    return fig

def plot_call_quality_metrics(df, qos_results):
    """
    Plot call quality metrics such as MOS and QCI.
    
    Args:
        df: DataFrame with drive test data
        qos_results: Dictionary with QoS analysis results
        
    Returns:
        fig: Plotly figure with call quality visualization
    """
    # Create a figure with subplots
    if 'MOS' in df.columns and not df['MOS'].isna().all():
        # Create a figure with MOS subplot
        fig = make_subplots(rows=1, cols=2, 
                           subplot_titles=["MOS Distribution", "QCI Distribution"],
                           column_widths=[0.5, 0.5])
        
        # Prepare MOS data
        df_mos = df.dropna(subset=['MOS']).copy()
        
        # Create MOS categories
        mos_bins = [0, 1, 2, 3, 3.5, 4, 4.5, 5]
        mos_labels = ['0-1', '1-2', '2-3', '3-3.5', '3.5-4', '4-4.5', '4.5-5']
        mos_colors = ['#d73027', '#f46d43', '#fdae61', '#fee08b', '#d9ef8b', '#a6d96a', '#66bd63']
        
        df_mos['MOS_Category'] = pd.cut(df_mos['MOS'], bins=mos_bins, labels=mos_labels)
        
        # Count samples in each category
        mos_counts = df_mos['MOS_Category'].value_counts().sort_index()
        
        # Add bar chart for MOS
        fig.add_trace(
            go.Bar(
                x=mos_counts.index,
                y=mos_counts.values,
                marker_color=mos_colors[:len(mos_counts)],
                text=mos_counts.values,
                textposition='auto',
                name="MOS"
            ),
            row=1, col=1
        )
        
        # Add a reference line for the threshold (3.5 is a common threshold for acceptable call quality)
        threshold_category = '3-3.5'
        if threshold_category in mos_counts.index:
            threshold_index = list(mos_counts.index).index(threshold_category)
            fig.add_shape(
                type="line",
                x0=threshold_category,
                y0=0,
                x1=threshold_category,
                y1=mos_counts.max() * 1.1,
                line=dict(
                    color="Red",
                    width=2,
                    dash="dash",
                ),
                row=1, col=1
            )
            
            fig.add_annotation(
                x=threshold_category,
                y=mos_counts.max() * 1.05,
                text="Threshold: 3.5",
                showarrow=False,
                font=dict(color="Red"),
                row=1, col=1
            )
        
        # Add a text annotation with statistics
        stats_text = (
            f"Avg MOS: {df_mos['MOS'].mean():.2f}<br>"
            f"Below 3.5: {(df_mos['MOS'] < 3.5).sum() / len(df_mos) * 100:.1f}%"
        )
        
        fig.add_annotation(
            x=0.95,
            y=0.95,
            xref="x1",
            yref="y1",
            text=stats_text,
            showarrow=False,
            align="right",
            bgcolor="rgba(255, 255, 255, 0.8)",
            bordercolor="black",
            borderwidth=1
        )
        
        # Update y-axis
        fig.update_yaxes(title_text="Number of Samples", row=1, col=1)
    else:
        # Create a simple figure
        fig = go.Figure()
        fig.add_annotation(
            text="No call quality data (MOS) available for visualization",
            showarrow=False,
            font=dict(size=16)
        )
        fig.update_layout(height=400)
        return fig
    
    # Add QCI distribution if available
    if 'QCI' in df.columns and not df['QCI'].isna().all():
        df_qci = df.dropna(subset=['QCI']).copy()
        
        # Count QCI values
        qci_counts = df_qci['QCI'].value_counts().sort_index()
        
        # Map QCI values to services if possible
        qci_service_map = {
            1: "Conversational Voice",
            2: "Conversational Video",
            3: "Real-Time Gaming",
            4: "Non-Conversational Video",
            5: "IMS Signaling",
            6: "Video, TCP services",
            7: "Voice, Video, Interactive Gaming",
            8: "Video, TCP services",
            9: "TCP services (e.g., web, email)",
            65: "Mission Critical Push To Talk",
            66: "Mission Critical Video",
            69: "Mission Critical Data",
            70: "Mission Critical Data"
        }
        
        # Create readable labels
        qci_labels = []
        for qci in qci_counts.index:
            if qci in qci_service_map:
                qci_labels.append(f"QCI {qci} ({qci_service_map[qci]})")
            else:
                qci_labels.append(f"QCI {qci}")
        
        # Add bar chart for QCI
        fig.add_trace(
            go.Bar(
                x=qci_labels,
                y=qci_counts.values,
                marker_color='#2ca02c',
                text=qci_counts.values,
                textposition='auto',
                name="QCI"
            ),
            row=1, col=2
        )
        
        # Update y-axis
        fig.update_yaxes(title_text="Number of Samples", row=1, col=2)
    else:
        # Add a message if no QCI data
        fig.add_annotation(
            x=0.75,
            y=0.5,
            text="No QCI data available",
            showarrow=False,
            font=dict(size=14),
            xref="paper",
            yref="paper"
        )
    
    # Update layout
    fig.update_layout(
        title_text="Call Quality Metrics",
        height=400,
        showlegend=False
    )
    
    return fig

def create_summary_dashboard(df, analysis_types):
    """
    Create a summary dashboard with key metrics.
    
    Args:
        df: DataFrame with drive test data
        analysis_types: List of selected analysis types
        
    Returns:
        fig: Plotly figure with summary dashboard
    """
    # Create a figure with subplots based on the selected analysis types
    num_rows = min(3, len(analysis_types))
    num_cols = min(2, (len(analysis_types) + 1) // 2)
    
    fig = make_subplots(
        rows=num_rows, 
        cols=num_cols,
        subplot_titles=[t for t in analysis_types[:num_rows*num_cols]],
        vertical_spacing=0.1,
        horizontal_spacing=0.1
    )
    
    # Track the current subplot position
    subplot_idx = 0
    
    # Add RF metrics summary if selected
    if "RF Metrics (RSRP, RSRQ, SINR)" in analysis_types and subplot_idx < num_rows * num_cols:
        row = subplot_idx // num_cols + 1
        col = subplot_idx % num_cols + 1
        
        # Prepare data
        if 'RSRP' in df.columns and 'RSRQ' in df.columns and 'SINR' in df.columns:
            df_rf = df.dropna(subset=['RSRP', 'RSRQ', 'SINR']).copy()
            
            if len(df_rf) > 0:
                # Create a radar chart for RF metrics
                categories = ['RSRP', 'RSRQ', 'SINR']
                
                # Normalize the metrics to 0-10 scale for visualization
                # RSRP: -140 to -70 dBm
                rsrp_norm = (df_rf['RSRP'].mean() - (-140)) / ((-70) - (-140)) * 10
                rsrp_norm = max(0, min(10, rsrp_norm))
                
                # RSRQ: -20 to 0 dB
                rsrq_norm = (df_rf['RSRQ'].mean() - (-20)) / (0 - (-20)) * 10
                rsrq_norm = max(0, min(10, rsrq_norm))
                
                # SINR: -10 to 30 dB
                sinr_norm = (df_rf['SINR'].mean() - (-10)) / (30 - (-10)) * 10
                sinr_norm = max(0, min(10, sinr_norm))
                
                values = [rsrp_norm, rsrq_norm, sinr_norm]
                
                fig.add_trace(
                    go.Scatterpolar(
                        r=values,
                        theta=categories,
                        fill='toself',
                        name='RF Metrics'
                    ),
                    row=row, col=col
                )
                
                # Add text annotations for actual values
                fig.add_annotation(
                    x=0.05 + (col-1)*0.5,
                    y=0.85 - (row-1)*0.33,
                    text=f"RSRP: {df_rf['RSRP'].mean():.2f} dBm<br>RSRQ: {df_rf['RSRQ'].mean():.2f} dB<br>SINR: {df_rf['SINR'].mean():.2f} dB",
                    showarrow=False,
                    xref="paper",
                    yref="paper",
                    align="left",
                    bgcolor="rgba(255, 255, 255, 0.8)",
                    bordercolor="black",
                    borderwidth=1
                )
                
                # Update layout for this subplot
                fig.update_layout(
                    polar=dict(
                        radialaxis=dict(
                            visible=True,
                            range=[0, 10]
                        )
                    )
                )
            else:
                # Add a message if no RF data
                fig.add_annotation(
                    x=0.25 + (col-1)*0.5,
                    y=0.5 - (row-1)*0.33,
                    text="No RF metrics data available",
                    showarrow=False,
                    font=dict(size=12),
                    xref="paper",
                    yref="paper"
                )
        else:
            # Add a message if missing RF metrics
            fig.add_annotation(
                x=0.25 + (col-1)*0.5,
                y=0.5 - (row-1)*0.33,
                text="Missing one or more RF metrics",
                showarrow=False,
                font=dict(size=12),
                xref="paper",
                yref="paper"
            )
        
        subplot_idx += 1
    
    # Add coverage problems summary if selected
    if "Coverage Problems" in analysis_types and subplot_idx < num_rows * num_cols:
        row = subplot_idx // num_cols + 1
        col = subplot_idx % num_cols + 1
        
        # Prepare data
        if 'RSRP' in df.columns:
            df_rsrp = df.dropna(subset=['RSRP']).copy()
            
            if len(df_rsrp) > 0:
                # Create a gauge chart for coverage quality
                rsrp_pct_good = (df_rsrp['RSRP'] >= -105).sum() / len(df_rsrp) * 100
                
                fig.add_trace(
                    go.Indicator(
                        mode="gauge+number",
                        value=rsrp_pct_good,
                        title={'text': "Coverage Quality"},
                        gauge={
                            'axis': {'range': [0, 100]},
                            'bar': {'color': "#19d3f3"},
                            'steps': [
                                {'range': [0, 50], 'color': "#ff0d57"},
                                {'range': [50, 80], 'color': "#ffc107"},
                                {'range': [80, 100], 'color': "#00b81f"}
                            ],
                            'threshold': {
                                'line': {'color': "red", 'width': 4},
                                'thickness': 0.75,
                                'value': 80
                            }
                        }
                    ),
                    row=row, col=col
                )
                
                # Add text annotation for RSRP stats
                fig.add_annotation(
                    x=0.05 + (col-1)*0.5,
                    y=0.15 - (row-1)*0.33,
                    text=f"Avg RSRP: {df_rsrp['RSRP'].mean():.2f} dBm<br>Poor Coverage: {100-rsrp_pct_good:.1f}%",
                    showarrow=False,
                    xref="paper",
                    yref="paper",
                    align="left",
                    bgcolor="rgba(255, 255, 255, 0.8)",
                    bordercolor="black",
                    borderwidth=1
                )
            else:
                # Add a message if no RSRP data
                fig.add_annotation(
                    x=0.25 + (col-1)*0.5,
                    y=0.5 - (row-1)*0.33,
                    text="No RSRP data available",
                    showarrow=False,
                    font=dict(size=12),
                    xref="paper",
                    yref="paper"
                )
        else:
            # Add a message if missing RSRP
            fig.add_annotation(
                x=0.25 + (col-1)*0.5,
                y=0.5 - (row-1)*0.33,
                text="RSRP data not available",
                showarrow=False,
                font=dict(size=12),
                xref="paper",
                yref="paper"
            )
        
        subplot_idx += 1
    
    # Add interference summary if selected
    if "Interference" in analysis_types and subplot_idx < num_rows * num_cols:
        row = subplot_idx // num_cols + 1
        col = subplot_idx % num_cols + 1
        
        # Prepare data
        if 'SINR' in df.columns:
            df_sinr = df.dropna(subset=['SINR']).copy()
            
            if len(df_sinr) > 0:
                # Create a gauge chart for interference level
                sinr_pct_good = (df_sinr['SINR'] >= 5).sum() / len(df_sinr) * 100
                
                fig.add_trace(
                    go.Indicator(
                        mode="gauge+number",
                        value=sinr_pct_good,
                        title={'text': "Low Interference"},
                        gauge={
                            'axis': {'range': [0, 100]},
                            'bar': {'color': "#19d3f3"},
                            'steps': [
                                {'range': [0, 50], 'color': "#ff0d57"},
                                {'range': [50, 80], 'color': "#ffc107"},
                                {'range': [80, 100], 'color': "#00b81f"}
                            ],
                            'threshold': {
                                'line': {'color': "red", 'width': 4},
                                'thickness': 0.75,
                                'value': 80
                            }
                        }
                    ),
                    row=row, col=col
                )
                
                # Add text annotation for SINR stats
                fig.add_annotation(
                    x=0.05 + (col-1)*0.5,
                    y=0.15 - (row-1)*0.33,
                    text=f"Avg SINR: {df_sinr['SINR'].mean():.2f} dB<br>High Interference: {100-sinr_pct_good:.1f}%",
                    showarrow=False,
                    xref="paper",
                    yref="paper",
                    align="left",
                    bgcolor="rgba(255, 255, 255, 0.8)",
                    bordercolor="black",
                    borderwidth=1
                )
            else:
                # Add a message if no SINR data
                fig.add_annotation(
                    x=0.25 + (col-1)*0.5,
                    y=0.5 - (row-1)*0.33,
                    text="No SINR data available",
                    showarrow=False,
                    font=dict(size=12),
                    xref="paper",
                    yref="paper"
                )
        else:
            # Add a message if missing SINR
            fig.add_annotation(
                x=0.25 + (col-1)*0.5,
                y=0.5 - (row-1)*0.33,
                text="SINR data not available",
                showarrow=False,
                font=dict(size=12),
                xref="paper",
                yref="paper"
            )
        
        subplot_idx += 1
    
    # Add handover analysis if selected
    if "Handover Failures" in analysis_types and subplot_idx < num_rows * num_cols:
        row = subplot_idx // num_cols + 1
        col = subplot_idx % num_cols + 1
        
        # Check for handover events
        has_handover_events = False
        
        if 'Handover_Event' in df.columns:
            has_handover_events = df['Handover_Event'].any()
        elif 'Event' in df.columns:
            has_handover_events = df['Event'].str.contains('handover|ho|cell_change', case=False, na=False).any()
        
        if has_handover_events:
            # Count handover events and estimate success rate
            ho_events = df['Handover_Event'].sum() if 'Handover_Event' in df.columns else df['Event'].str.contains('handover|ho|cell_change', case=False, na=False).sum()
            
            # Estimate failure rate (just for visualization)
            ho_failures = 0
            if 'Event' in df.columns and 'Event_Detail' in df.columns:
                ho_failures = df[
                    df['Event'].str.contains('handover|ho|cell_change', case=False, na=False) &
                    df['Event_Detail'].str.contains('fail|error|reject', case=False, na=False)
                ].shape[0]
            
            ho_success_rate = ((ho_events - ho_failures) / ho_events) * 100 if ho_events > 0 else 100
            
            # Create a gauge chart for handover success rate
            fig.add_trace(
                go.Indicator(
                    mode="gauge+number",
                    value=ho_success_rate,
                    title={'text': "HO Success Rate"},
                    gauge={
                        'axis': {'range': [0, 100]},
                        'bar': {'color': "#19d3f3"},
                        'steps': [
                            {'range': [0, 90], 'color': "#ff0d57"},
                            {'range': [90, 95], 'color': "#ffc107"},
                            {'range': [95, 100], 'color': "#00b81f"}
                        ],
                        'threshold': {
                            'line': {'color': "red", 'width': 4},
                            'thickness': 0.75,
                            'value': 95
                        }
                    }
                ),
                row=row, col=col
            )
            
            # Add text annotation for handover stats
            fig.add_annotation(
                x=0.05 + (col-1)*0.5,
                y=0.15 - (row-1)*0.33,
                text=f"Total HOs: {ho_events}<br>Failed HOs: {ho_failures}",
                showarrow=False,
                xref="paper",
                yref="paper",
                align="left",
                bgcolor="rgba(255, 255, 255, 0.8)",
                bordercolor="black",
                borderwidth=1
            )
        else:
            # Add a message if no handover events
            fig.add_annotation(
                x=0.25 + (col-1)*0.5,
                y=0.5 - (row-1)*0.33,
                text="No handover events detected",
                showarrow=False,
                font=dict(size=12),
                xref="paper",
                yref="paper"
            )
        
        subplot_idx += 1
    
    # Add throughput analysis if selected
    if "Throughput Bottlenecks" in analysis_types and subplot_idx < num_rows * num_cols:
        row = subplot_idx // num_cols + 1
        col = subplot_idx % num_cols + 1
        
        # Prepare data
        if 'Throughput_DL' in df.columns and not df['Throughput_DL'].isna().all():
            df_dl = df.dropna(subset=['Throughput_DL']).copy()
            
            if len(df_dl) > 0:
                # Create a gauge chart for throughput quality
                dl_pct_good = (df_dl['Throughput_DL'] >= 5).sum() / len(df_dl) * 100
                
                fig.add_trace(
                    go.Indicator(
                        mode="gauge+number+delta",
                        value=df_dl['Throughput_DL'].mean(),
                        title={'text': "Avg DL Throughput (Mbps)"},
                        delta={'reference': 10, 'increasing': {'color': "green"}, 'decreasing': {'color': "red"}},
                        gauge={
                            'axis': {'range': [0, max(20, df_dl['Throughput_DL'].mean() * 1.5)]},
                            'bar': {'color': "#19d3f3"},
                            'steps': [
                                {'range': [0, 5], 'color': "#ff0d57"},
                                {'range': [5, 10], 'color': "#ffc107"},
                                {'range': [10, 100], 'color': "#00b81f"}
                            ],
                            'threshold': {
                                'line': {'color': "red", 'width': 4},
                                'thickness': 0.75,
                                'value': 5
                            }
                        }
                    ),
                    row=row, col=col
                )
                
                # Add text annotation for throughput stats
                fig.add_annotation(
                    x=0.05 + (col-1)*0.5,
                    y=0.15 - (row-1)*0.33,
                    text=f"Max DL: {df_dl['Throughput_DL'].max():.2f} Mbps<br>Low TP: {100-dl_pct_good:.1f}%",
                    showarrow=False,
                    xref="paper",
                    yref="paper",
                    align="left",
                    bgcolor="rgba(255, 255, 255, 0.8)",
                    bordercolor="black",
                    borderwidth=1
                )
            else:
                # Add a message if no throughput data
                fig.add_annotation(
                    x=0.25 + (col-1)*0.5,
                    y=0.5 - (row-1)*0.33,
                    text="No throughput data available",
                    showarrow=False,
                    font=dict(size=12),
                    xref="paper",
                    yref="paper"
                )
        else:
            # Add a message if missing throughput
            fig.add_annotation(
                x=0.25 + (col-1)*0.5,
                y=0.5 - (row-1)*0.33,
                text="Throughput data not available",
                showarrow=False,
                font=dict(size=12),
                xref="paper",
                yref="paper"
            )
        
        subplot_idx += 1
    
    # Add call drops analysis if selected
    if "Call Drops" in analysis_types and subplot_idx < num_rows * num_cols:
        row = subplot_idx // num_cols + 1
        col = subplot_idx % num_cols + 1
        
        # Check for call events
        has_call_events = False
        
        if 'Call_State' in df.columns:
            has_call_events = True
        elif 'Event' in df.columns:
            has_call_events = df['Event'].str.contains('call|volte|csfb', case=False, na=False).any()
        
        if has_call_events:
            # Count call events and estimate drop rate
            call_start_events = 0
            call_drop_events = 0
            
            if 'Call_State' in df.columns:
                # Count transitions to Active state
                df['Call_State_Prev'] = df['Call_State'].shift(1)
                call_start_events = ((df['Call_State'] == 'Active') & 
                                     ((df['Call_State_Prev'] != 'Active') | 
                                      df['Call_State_Prev'].isna())).sum()
                
                # Count transitions to Dropped state
                call_drop_events = ((df['Call_State'] == 'Dropped') & 
                                    (df['Call_State_Prev'] == 'Active')).sum()
            elif 'Event' in df.columns:
                # Count call start events
                call_start_events = df['Event'].str.contains('call_setup|call start|call_initiated|volte_start|csfb_start', 
                                                             case=False, na=False).sum()
                
                # Count call drop events
                call_drop_events = df['Event'].str.contains('call_drop|call dropped|drop|volte_drop|csfb_drop', 
                                                           case=False, na=False).sum()
            
            # Calculate drop rate
            drop_rate = (call_drop_events / call_start_events) * 100 if call_start_events > 0 else 0
            success_rate = 100 - drop_rate
            
            # Create a gauge chart for call success rate
            fig.add_trace(
                go.Indicator(
                    mode="gauge+number",
                    value=success_rate,
                    title={'text': "Call Success Rate"},
                    gauge={
                        'axis': {'range': [0, 100]},
                        'bar': {'color': "#19d3f3"},
                        'steps': [
                            {'range': [0, 95], 'color': "#ff0d57"},
                            {'range': [95, 98], 'color': "#ffc107"},
                            {'range': [98, 100], 'color': "#00b81f"}
                        ],
                        'threshold': {
                            'line': {'color': "red", 'width': 4},
                            'thickness': 0.75,
                            'value': 98
                        }
                    }
                ),
                row=row, col=col
            )
            
            # Add text annotation for call stats
            fig.add_annotation(
                x=0.05 + (col-1)*0.5,
                y=0.15 - (row-1)*0.33,
                text=f"Total Calls: {call_start_events}<br>Dropped Calls: {call_drop_events}",
                showarrow=False,
                xref="paper",
                yref="paper",
                align="left",
                bgcolor="rgba(255, 255, 255, 0.8)",
                bordercolor="black",
                borderwidth=1
            )
        else:
            # Add a message if no call events
            fig.add_annotation(
                x=0.25 + (col-1)*0.5,
                y=0.5 - (row-1)*0.33,
                text="No call events detected",
                showarrow=False,
                font=dict(size=12),
                xref="paper",
                yref="paper"
            )
        
        subplot_idx += 1
    
    # Update layout
    fig.update_layout(
        title_text="Network Performance Summary",
        height=num_rows * 300,
        showlegend=False
    )
    
    return fig
