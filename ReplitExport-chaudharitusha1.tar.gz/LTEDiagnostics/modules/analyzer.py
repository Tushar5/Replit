import pandas as pd
import numpy as np
from datetime import datetime

def analyze_coverage_problems(df, rsrp_threshold=-105, rsrq_threshold=-15):
    """
    Analyze coverage problems in the drive test data.
    
    Args:
        df: DataFrame with drive test data
        rsrp_threshold: RSRP threshold in dBm for poor coverage
        rsrq_threshold: RSRQ threshold in dB for poor coverage
        
    Returns:
        dict: Coverage analysis results
    """
    # Filter out rows with missing RSRP or RSRQ
    df_filtered = df.dropna(subset=['RSRP', 'RSRQ'])
    
    if len(df_filtered) == 0:
        return {
            'coverage_issues_pct': 0,
            'critical_areas': 0,
            'problem_areas': pd.DataFrame()
        }
    
    # Identify coverage issues
    coverage_issues = (df_filtered['RSRP'] < rsrp_threshold) | (df_filtered['RSRQ'] < rsrq_threshold)
    
    # Calculate percentage of samples with coverage issues
    coverage_issues_pct = (coverage_issues.sum() / len(df_filtered)) * 100
    
    # Find critical areas (continuous stretches of poor coverage)
    df_filtered['Coverage_Issue'] = coverage_issues
    
    # Group nearby points with coverage issues
    df_filtered['Issue_Group'] = (df_filtered['Coverage_Issue'] != df_filtered['Coverage_Issue'].shift(1)).cumsum()
    
    # Find continuous areas with coverage issues
    issue_groups = df_filtered[df_filtered['Coverage_Issue']].groupby('Issue_Group')
    
    # Filter for significant problem areas (at least 5 consecutive samples)
    significant_issues = [group for name, group in issue_groups if len(group) >= 5]
    
    # Create a DataFrame with problem areas
    problem_areas = []
    for i, issue_area in enumerate(significant_issues):
        problem_areas.append({
            'Area_ID': i + 1,
            'Start_Time': issue_area['Timestamp'].min(),
            'End_Time': issue_area['Timestamp'].max(),
            'Duration_Seconds': (issue_area['Timestamp'].max() - issue_area['Timestamp'].min()).total_seconds(),
            'Avg_RSRP': issue_area['RSRP'].mean(),
            'Avg_RSRQ': issue_area['RSRQ'].mean(),
            'Samples': len(issue_area),
            'Latitude': issue_area['Latitude'].mean(),
            'Longitude': issue_area['Longitude'].mean(),
            'Main_Cell_ID': issue_area['CellID'].mode()[0] if 'CellID' in issue_area and len(issue_area['CellID'].mode()) > 0 else 'Unknown'
        })
    
    return {
        'coverage_issues_pct': coverage_issues_pct,
        'critical_areas': len(problem_areas),
        'problem_areas': pd.DataFrame(problem_areas) if problem_areas else pd.DataFrame()
    }

def analyze_interference(df, sinr_threshold=5):
    """
    Analyze interference issues in the drive test data.
    
    Args:
        df: DataFrame with drive test data
        sinr_threshold: SINR threshold in dB for interference detection
        
    Returns:
        dict: Interference analysis results
    """
    # Filter out rows with missing SINR
    df_filtered = df.dropna(subset=['SINR'])
    
    if len(df_filtered) == 0:
        return {
            'interference_issues_pct': 0,
            'high_interference_areas': 0,
            'problem_areas': pd.DataFrame()
        }
    
    # Identify interference issues (low SINR)
    interference_issues = df_filtered['SINR'] < sinr_threshold
    
    # Calculate percentage of samples with interference issues
    interference_issues_pct = (interference_issues.sum() / len(df_filtered)) * 100
    
    # Find high interference areas (continuous stretches of low SINR)
    df_filtered['Interference_Issue'] = interference_issues
    
    # Group nearby points with interference issues
    df_filtered['Issue_Group'] = (df_filtered['Interference_Issue'] != df_filtered['Interference_Issue'].shift(1)).cumsum()
    
    # Find continuous areas with interference issues
    issue_groups = df_filtered[df_filtered['Interference_Issue']].groupby('Issue_Group')
    
    # Filter for significant problem areas (at least 5 consecutive samples)
    significant_issues = [group for name, group in issue_groups if len(group) >= 5]
    
    # Create a DataFrame with problem areas
    problem_areas = []
    for i, issue_area in enumerate(significant_issues):
        problem_areas.append({
            'Area_ID': i + 1,
            'Start_Time': issue_area['Timestamp'].min(),
            'End_Time': issue_area['Timestamp'].max(),
            'Duration_Seconds': (issue_area['Timestamp'].max() - issue_area['Timestamp'].min()).total_seconds(),
            'Avg_SINR': issue_area['SINR'].mean(),
            'Avg_RSRP': issue_area['RSRP'].mean() if 'RSRP' in issue_area else None,
            'Samples': len(issue_area),
            'Latitude': issue_area['Latitude'].mean(),
            'Longitude': issue_area['Longitude'].mean(),
            'Main_Cell_ID': issue_area['CellID'].mode()[0] if 'CellID' in issue_area and len(issue_area['CellID'].mode()) > 0 else 'Unknown'
        })
    
    return {
        'interference_issues_pct': interference_issues_pct,
        'high_interference_areas': len(problem_areas),
        'problem_areas': pd.DataFrame(problem_areas) if problem_areas else pd.DataFrame()
    }

def analyze_handover_failures(df):
    """
    Analyze handover failures in the drive test data.
    
    Args:
        df: DataFrame with drive test data
        
    Returns:
        dict: Handover analysis results
    """
    # Check if handover events column exists
    if 'Handover_Event' not in df.columns and 'Event' not in df.columns:
        # Try to create handover events column if possible
        if 'PCI' in df.columns:
            df['Handover_Event'] = (df['PCI'] != df['PCI'].shift(1)) & (~df['PCI'].isna()) & (~df['PCI'].shift(1).isna())
        else:
            return {
                'total_handovers': 0,
                'successful_handovers': 0,
                'failed_handovers': 0,
                'handover_success_rate': 100.0,
                'failure_causes': {},
                'handover_details': pd.DataFrame()
            }
    
    # Extract handover events
    if 'Handover_Event' in df.columns:
        # Use the derived Handover_Event column
        handover_events = df[df['Handover_Event'] == True].copy()
    else:
        # Try to find handover events in the Event column
        handover_keywords = ['handover', 'ho', 'cell_change', 'cell change', 'reselection']
        handover_events = df[df['Event'].str.lower().str.contains('|'.join(handover_keywords), na=False)].copy()
    
    if len(handover_events) == 0:
        return {
            'total_handovers': 0,
            'successful_handovers': 0,
            'failed_handovers': 0,
            'handover_success_rate': 100.0,
            'failure_causes': {},
            'handover_details': pd.DataFrame()
        }
    
    # Determine handover success/failure
    # In this implementation, we'll consider a handover successful if there's no
    # "failure" or "error" in the Event_Detail, or if RF metrics after handover are good
    
    # Method 1: Check for failure keywords in Event_Detail
    if 'Event_Detail' in handover_events.columns:
        failure_keywords = ['fail', 'error', 'timeout', 'reject', 'abort']
        handover_events['Handover_Success'] = ~handover_events['Event_Detail'].str.lower().str.contains('|'.join(failure_keywords), na=False)
    else:
        # Method 2: Check RF metrics after handover
        handover_events['Handover_Success'] = True  # Default to success
        
        # If we have indexes, we can check post-handover RF metrics
        if 'RSRP' in df.columns and 'SINR' in df.columns:
            for idx, row in handover_events.iterrows():
                # Get index in the original dataframe
                orig_idx = df.index.get_loc(idx)
                
                # Check if there are at least 5 samples after the handover
                if orig_idx + 5 < len(df):
                    # Get average RSRP and SINR after handover
                    post_handover_df = df.iloc[orig_idx+1:orig_idx+6]
                    avg_rsrp = post_handover_df['RSRP'].mean()
                    avg_sinr = post_handover_df['SINR'].mean()
                    
                    # If RF metrics are poor after handover, consider it a failure
                    if avg_rsrp < -110 or avg_sinr < 0:
                        handover_events.at[idx, 'Handover_Success'] = False
    
    # Count successful and failed handovers
    total_handovers = len(handover_events)
    successful_handovers = handover_events['Handover_Success'].sum()
    failed_handovers = total_handovers - successful_handovers
    
    # Calculate success rate
    handover_success_rate = (successful_handovers / total_handovers) * 100 if total_handovers > 0 else 100.0
    
    # Analyze failure causes
    failure_causes = {}
    
    if 'Event_Detail' in handover_events.columns:
        failed_handovers_df = handover_events[handover_events['Handover_Success'] == False]
        
        # Extract failure cause from Event_Detail
        for _, row in failed_handovers_df.iterrows():
            event_detail = row['Event_Detail'] if pd.notna(row['Event_Detail']) else "Unknown"
            
            # Try to extract a cause
            if 'cause:' in event_detail.lower():
                cause = event_detail.lower().split('cause:')[1].strip().split()[0]
            elif 'timeout' in event_detail.lower():
                cause = "Timeout"
            elif 'reject' in event_detail.lower():
                cause = "Rejected"
            elif 'fail' in event_detail.lower():
                cause = "Failed"
            else:
                cause = "Unknown"
            
            if cause in failure_causes:
                failure_causes[cause] += 1
            else:
                failure_causes[cause] = 1
    
    # Add source and target cell info to handover events
    handover_details = handover_events.copy()
    
    if 'CellID' in df.columns:
        handover_details['Source_Cell'] = [
            df.loc[:idx, 'CellID'].iloc[-2] if idx > 0 and df.index.get_loc(idx) > 0 else None
            for idx in handover_details.index
        ]
        
        handover_details['Target_Cell'] = [
            df.loc[idx:, 'CellID'].iloc[1] if idx < df.index[-1] and df.index.get_loc(idx) < len(df) - 1 else None
            for idx in handover_details.index
        ]
    
    return {
        'total_handovers': total_handovers,
        'successful_handovers': successful_handovers,
        'failed_handovers': failed_handovers,
        'handover_success_rate': handover_success_rate,
        'failure_causes': failure_causes,
        'handover_details': handover_details
    }

def analyze_throughput_bottlenecks(df):
    """
    Analyze throughput bottlenecks in the drive test data.
    
    Args:
        df: DataFrame with drive test data
        
    Returns:
        dict: Throughput analysis results
    """
    # Check if throughput columns exist
    has_dl_throughput = 'Throughput_DL' in df.columns and not df['Throughput_DL'].isna().all()
    has_ul_throughput = 'Throughput_UL' in df.columns and not df['Throughput_UL'].isna().all()
    
    if not has_dl_throughput and not has_ul_throughput:
        return {
            'avg_dl_throughput': 0,
            'avg_ul_throughput': 0,
            'peak_dl_throughput': 0,
            'peak_ul_throughput': 0,
            'dl_bottleneck_areas': 0,
            'ul_bottleneck_areas': 0,
            'bottleneck_causes': {},
            'bottleneck_areas': pd.DataFrame()
        }
    
    # Calculate basic throughput statistics
    avg_dl_throughput = df['Throughput_DL'].mean() if has_dl_throughput else 0
    avg_ul_throughput = df['Throughput_UL'].mean() if has_ul_throughput else 0
    peak_dl_throughput = df['Throughput_DL'].max() if has_dl_throughput else 0
    peak_ul_throughput = df['Throughput_UL'].max() if has_ul_throughput else 0
    
    # Define bottleneck thresholds
    # We'll use dynamic thresholds based on the average and percentiles
    dl_threshold = df['Throughput_DL'].quantile(0.25) if has_dl_throughput else 0
    ul_threshold = df['Throughput_UL'].quantile(0.25) if has_ul_throughput else 0
    
    # Ensure minimum threshold values
    dl_threshold = max(dl_threshold, 1.0)  # At least 1 Mbps for DL
    ul_threshold = max(ul_threshold, 0.5)  # At least 0.5 Mbps for UL
    
    # Identify throughput bottlenecks
    dl_bottlenecks = (df['Throughput_DL'] < dl_threshold) if has_dl_throughput else pd.Series(False, index=df.index)
    ul_bottlenecks = (df['Throughput_UL'] < ul_threshold) if has_ul_throughput else pd.Series(False, index=df.index)
    
    # Combined bottleneck
    bottlenecks = dl_bottlenecks | ul_bottlenecks
    
    # Find bottleneck areas (continuous stretches of low throughput)
    df_bottlenecks = df.copy()
    df_bottlenecks['DL_Bottleneck'] = dl_bottlenecks
    df_bottlenecks['UL_Bottleneck'] = ul_bottlenecks
    df_bottlenecks['Any_Bottleneck'] = bottlenecks
    
    # Group nearby points with bottlenecks
    df_bottlenecks['Bottleneck_Group'] = (df_bottlenecks['Any_Bottleneck'] != df_bottlenecks['Any_Bottleneck'].shift(1)).cumsum()
    
    # Find continuous areas with bottlenecks
    bottleneck_groups = df_bottlenecks[df_bottlenecks['Any_Bottleneck']].groupby('Bottleneck_Group')
    
    # Filter for significant bottleneck areas (at least 5 consecutive samples)
    significant_bottlenecks = [group for name, group in bottleneck_groups if len(group) >= 5]
    
    # Create a DataFrame with bottleneck areas
    bottleneck_areas = []
    for i, bottleneck_area in enumerate(significant_bottlenecks):
        # Determine the type of bottleneck
        dl_bottleneck_pct = bottleneck_area['DL_Bottleneck'].mean() * 100
        ul_bottleneck_pct = bottleneck_area['UL_Bottleneck'].mean() * 100
        
        bottleneck_type = []
        if dl_bottleneck_pct > 50:
            bottleneck_type.append('DL')
        if ul_bottleneck_pct > 50:
            bottleneck_type.append('UL')
        
        bottleneck_areas.append({
            'Area_ID': i + 1,
            'Start_Time': bottleneck_area['Timestamp'].min(),
            'End_Time': bottleneck_area['Timestamp'].max(),
            'Duration_Seconds': (bottleneck_area['Timestamp'].max() - bottleneck_area['Timestamp'].min()).total_seconds(),
            'Avg_DL_Throughput': bottleneck_area['Throughput_DL'].mean() if has_dl_throughput else None,
            'Avg_UL_Throughput': bottleneck_area['Throughput_UL'].mean() if has_ul_throughput else None,
            'Bottleneck_Type': '+'.join(bottleneck_type),
            'Samples': len(bottleneck_area),
            'Latitude': bottleneck_area['Latitude'].mean(),
            'Longitude': bottleneck_area['Longitude'].mean(),
            'Avg_RSRP': bottleneck_area['RSRP'].mean() if 'RSRP' in bottleneck_area.columns else None,
            'Avg_SINR': bottleneck_area['SINR'].mean() if 'SINR' in bottleneck_area.columns else None,
            'Main_Cell_ID': bottleneck_area['CellID'].mode()[0] if 'CellID' in bottleneck_area and len(bottleneck_area['CellID'].mode()) > 0 else 'Unknown'
        })
    
    # Count bottleneck areas by type
    dl_bottleneck_areas = sum(1 for area in bottleneck_areas if 'DL' in area['Bottleneck_Type'])
    ul_bottleneck_areas = sum(1 for area in bottleneck_areas if 'UL' in area['Bottleneck_Type'])
    
    # Determine causes of bottlenecks
    bottleneck_causes = {}
    
    for area in bottleneck_areas:
        cause = "Unknown"
        
        # Check if we have RSRP and SINR data to determine the cause
        if area['Avg_RSRP'] is not None and area['Avg_SINR'] is not None:
            if area['Avg_RSRP'] < -110:
                cause = "Poor Coverage"
            elif area['Avg_SINR'] < 5:
                cause = "High Interference"
            else:
                cause = "Possible Cell Congestion"
        
        if cause in bottleneck_causes:
            bottleneck_causes[cause] += 1
        else:
            bottleneck_causes[cause] = 1
    
    return {
        'avg_dl_throughput': avg_dl_throughput,
        'avg_ul_throughput': avg_ul_throughput,
        'peak_dl_throughput': peak_dl_throughput,
        'peak_ul_throughput': peak_ul_throughput,
        'dl_bottleneck_areas': dl_bottleneck_areas,
        'ul_bottleneck_areas': ul_bottleneck_areas,
        'bottleneck_causes': bottleneck_causes,
        'bottleneck_areas': pd.DataFrame(bottleneck_areas) if bottleneck_areas else pd.DataFrame()
    }

def analyze_call_drops(df):
    """
    Analyze call drops in the drive test data.
    
    Args:
        df: DataFrame with drive test data
        
    Returns:
        dict: Call drop analysis results
    """
    # Check if we have call state or event data
    if 'Call_State' not in df.columns and 'Event' not in df.columns:
        return {
            'total_calls': 0,
            'completed_calls': 0,
            'dropped_calls': 0,
            'call_drop_rate': 0,
            'drop_causes': {},
            'drop_details': pd.DataFrame()
        }
    
    # Try to extract call events
    call_events = pd.DataFrame()
    
    if 'Event' in df.columns:
        # Filter events related to calls
        call_start_events = df[df['Event'].str.contains('call_setup|call start|call_initiated|volte_start|csfb_start', 
                                                        case=False, regex=True, na=False)]
        
        call_end_events = df[df['Event'].str.contains('call_end|call complete|call terminated|call_terminated|volte_end|csfb_end', 
                                                      case=False, regex=True, na=False)]
        
        call_drop_events = df[df['Event'].str.contains('call_drop|call dropped|drop|failure|volte_drop|csfb_drop', 
                                                       case=False, regex=True, na=False)]
        
        # Count events
        total_calls = len(call_start_events)
        dropped_calls = len(call_drop_events)
        completed_calls = len(call_end_events) - dropped_calls
        
        # Ensure counts are non-negative
        completed_calls = max(0, completed_calls)
        
        # Calculate call drop rate
        call_drop_rate = (dropped_calls / total_calls * 100) if total_calls > 0 else 0
        
        # Extract drop causes
        drop_causes = {}
        
        if 'Event_Detail' in df.columns:
            for _, row in call_drop_events.iterrows():
                event_detail = row['Event_Detail'] if pd.notna(row['Event_Detail']) else "Unknown"
                
                # Try to extract a cause
                if 'cause:' in event_detail.lower():
                    cause = event_detail.lower().split('cause:')[1].strip().split()[0]
                elif 'rf_condition' in event_detail.lower() or 'poor rf' in event_detail.lower():
                    cause = "Poor RF Conditions"
                elif 'timeout' in event_detail.lower():
                    cause = "Timeout"
                elif 'no resource' in event_detail.lower() or 'congestion' in event_detail.lower():
                    cause = "Network Congestion"
                else:
                    cause = "Unknown"
                
                if cause in drop_causes:
                    drop_causes[cause] += 1
                else:
                    drop_causes[cause] = 1
        
        # Prepare drop details
        drop_details = call_drop_events.copy()
        
        # Add RF metrics at drop time
        if 'RSRP' in df.columns and 'RSRQ' in df.columns and 'SINR' in df.columns:
            drop_details['RSRP_at_Drop'] = drop_details['RSRP']
            drop_details['RSRQ_at_Drop'] = drop_details['RSRQ']
            drop_details['SINR_at_Drop'] = drop_details['SINR']
    
    elif 'Call_State' in df.columns:
        # Try to identify call start/end/drop events from Call_State transitions
        df['Call_State_Prev'] = df['Call_State'].shift(1)
        
        # Identify call start (when state changes from None/Idle to Active)
        call_start_mask = (df['Call_State'] == 'Active') & ((df['Call_State_Prev'] != 'Active') | df['Call_State_Prev'].isna())
        call_start_events = df[call_start_mask]
        
        # Identify call end (when state changes from Active to None/Idle)
        call_end_mask = (df['Call_State'] != 'Active') & (df['Call_State_Prev'] == 'Active')
        call_end_events = df[call_end_mask]
        
        # Identify call drop (when state changes from Active to Dropped/Failed)
        call_drop_mask = ((df['Call_State'] == 'Dropped') | (df['Call_State'] == 'Failed')) & (df['Call_State_Prev'] == 'Active')
        call_drop_events = df[call_drop_mask]
        
        # Count events
        total_calls = len(call_start_events)
        dropped_calls = len(call_drop_events)
        completed_calls = total_calls - dropped_calls
        
        # Ensure counts are non-negative
        completed_calls = max(0, completed_calls)
        
        # Calculate call drop rate
        call_drop_rate = (dropped_calls / total_calls * 100) if total_calls > 0 else 0
        
        # Try to determine causes of drops
        drop_causes = {}
        
        # Check RF metrics at drop time
        if 'RSRP' in df.columns and 'SINR' in df.columns:
            for idx, row in call_drop_events.iterrows():
                # Check RF metrics at drop time
                rsrp = row['RSRP']
                sinr = row['SINR']
                
                if rsrp < -110:
                    cause = "Poor Coverage"
                elif sinr < 5:
                    cause = "High Interference"
                else:
                    cause = "Unknown"
                
                if cause in drop_causes:
                    drop_causes[cause] += 1
                else:
                    drop_causes[cause] = 1
        
        # Prepare drop details
        drop_details = call_drop_events.copy()
        
        # Add RF metrics at drop time
        if 'RSRP' in df.columns and 'RSRQ' in df.columns and 'SINR' in df.columns:
            drop_details['RSRP_at_Drop'] = drop_details['RSRP']
            drop_details['RSRQ_at_Drop'] = drop_details['RSRQ']
            drop_details['SINR_at_Drop'] = drop_details['SINR']
    
    # Default values if no call data was found
    if 'total_calls' not in locals():
        total_calls = 0
        completed_calls = 0
        dropped_calls = 0
        call_drop_rate = 0
        drop_causes = {}
        drop_details = pd.DataFrame()
    
    return {
        'total_calls': total_calls,
        'completed_calls': completed_calls,
        'dropped_calls': dropped_calls,
        'call_drop_rate': call_drop_rate,
        'drop_causes': drop_causes,
        'drop_details': drop_details
    }

def analyze_cell_overloading(df):
    """
    Analyze cell overloading in the drive test data.
    
    Args:
        df: DataFrame with drive test data
        
    Returns:
        dict: Cell overloading analysis results
    """
    # Check if we have necessary columns
    if 'CellID' not in df.columns:
        return {
            'overloaded_cells': pd.DataFrame(),
            'cell_loading': {}
        }
    
    # Group by cell ID
    cell_groups = df.groupby('CellID')
    
    # Track cell statistics
    cell_stats = []
    
    for cell_id, cell_data in cell_groups:
        # Skip if cell_id is NaN
        if pd.isna(cell_id) or cell_id == '':
            continue
        
        # Calculate metrics for each cell
        avg_throughput_dl = cell_data['Throughput_DL'].mean() if 'Throughput_DL' in cell_data else None
        avg_throughput_ul = cell_data['Throughput_UL'].mean() if 'Throughput_UL' in cell_data else None
        avg_rsrp = cell_data['RSRP'].mean() if 'RSRP' in cell_data else None
        avg_sinr = cell_data['SINR'].mean() if 'SINR' in cell_data else None
        
        # Check for symptoms of overloading
        overloading_score = 0
        reasons = []
        
        # Check throughput - lower throughput might indicate congestion
        if avg_throughput_dl is not None and avg_throughput_dl < 5:  # Below 5 Mbps DL
            overloading_score += 1
            reasons.append("Low DL Throughput")
        
        # Check for QCI changes - QCI downgrades might indicate congestion
        if 'QCI' in cell_data:
            qci_changes = (cell_data['QCI'] != cell_data['QCI'].shift(1)).sum()
            qci_change_rate = qci_changes / len(cell_data)
            
            if qci_change_rate > 0.05:  # More than 5% QCI changes
                overloading_score += 1
                reasons.append("Frequent QCI Changes")
        
        # Check for high number of users (if available)
        if 'ConnectedUsers' in cell_data:
            avg_users = cell_data['ConnectedUsers'].mean()
            if avg_users > 30:  # More than 30 connected users on average
                overloading_score += 1
                reasons.append("High User Count")
        
        # Check for handover failures to this cell
        if 'Event' in cell_data and 'Event_Detail' in cell_data:
            ho_failures = cell_data[
                (cell_data['Event'].str.contains('handover', case=False, na=False)) &
                (cell_data['Event_Detail'].str.contains('failure|congestion|no resource', case=False, na=False))
            ]
            
            if len(ho_failures) > 0:
                overloading_score += 1
                reasons.append("Handover Failures")
        
        # Calculate an overall overloading probability
        if overloading_score >= 2:
            cell_stats.append({
                'CellID': cell_id,
                'Overloading_Score': overloading_score,
                'Avg_DL_Throughput': avg_throughput_dl,
                'Avg_UL_Throughput': avg_throughput_ul,
                'Avg_RSRP': avg_rsrp,
                'Avg_SINR': avg_sinr,
                'Sample_Count': len(cell_data),
                'Overloading_Indicators': ', '.join(reasons)
            })
    
    # Create a DataFrame of potentially overloaded cells
    overloaded_cells = pd.DataFrame(cell_stats).sort_values('Overloading_Score', ascending=False)
    
    # Calculate overall cell loading statistics
    cell_loading = {}
    for cell_id, cell_data in cell_groups:
        if pd.isna(cell_id) or cell_id == '':
            continue
        
        # Calculate loading estimate
        loading_estimate = 0
        
        # Base estimate on throughput if available
        if 'Throughput_DL' in cell_data:
            # Lower throughput might indicate higher loading
            avg_dl = max(0.1, cell_data['Throughput_DL'].mean())  # Avoid division by zero
            loading_estimate += min(100, 50 / avg_dl * 10)  # Scale factor
        
        # Adjust based on SINR if available
        if 'SINR' in cell_data:
            # Lower SINR might indicate higher interference or loading
            avg_sinr = max(0.1, cell_data['SINR'].mean())  # Avoid division by zero
            loading_estimate += min(50, 10 / avg_sinr * 10)  # Scale factor
        
        # Normalize to 0-100 scale
        loading_estimate = min(100, loading_estimate)
        
        cell_loading[cell_id] = loading_estimate
    
    return {
        'overloaded_cells': overloaded_cells,
        'cell_loading': cell_loading
    }

def analyze_parameter_mismatches(df):
    """
    Analyze parameter mismatches in the drive test data.
    
    Args:
        df: DataFrame with drive test data
        
    Returns:
        dict: Parameter mismatch analysis results
    """
    # Check if we have necessary columns
    required_columns = ['CellID', 'EARFCN', 'PCI']
    if not all(col in df.columns for col in required_columns):
        return {
            'parameter_mismatches': pd.DataFrame(),
            'mismatch_count': 0
        }
    
    # Group by cell ID
    cell_groups = df.groupby('CellID')
    
    # Track parameter mismatches
    parameter_mismatches = []
    
    for cell_id, cell_data in cell_groups:
        # Skip if cell_id is NaN
        if pd.isna(cell_id) or cell_id == '':
            continue
        
        # Check for EARFCN inconsistencies within the same cell
        earfcn_values = cell_data['EARFCN'].dropna().unique()
        if len(earfcn_values) > 1:
            parameter_mismatches.append({
                'CellID': cell_id,
                'Parameter': 'EARFCN',
                'Expected': earfcn_values[0],
                'Observed': str(list(earfcn_values)),
                'Samples': len(cell_data),
                'Description': f"Cell {cell_id} has inconsistent EARFCN values"
            })
        
        # Check for PCI inconsistencies within the same cell
        pci_values = cell_data['PCI'].dropna().unique()
        if len(pci_values) > 1:
            parameter_mismatches.append({
                'CellID': cell_id,
                'Parameter': 'PCI',
                'Expected': pci_values[0],
                'Observed': str(list(pci_values)),
                'Samples': len(cell_data),
                'Description': f"Cell {cell_id} has inconsistent PCI values"
            })
        
        # Check for PCI conflicts between different cells
        for other_cell_id, other_cell_data in cell_groups:
            if cell_id != other_cell_id and not pd.isna(other_cell_id) and other_cell_id != '':
                # Get the most common PCI for each cell
                cell_pci = cell_data['PCI'].mode()[0] if len(cell_data['PCI'].mode()) > 0 else None
                other_pci = other_cell_data['PCI'].mode()[0] if len(other_cell_data['PCI'].mode()) > 0 else None
                
                # Check if both cells have the same PCI
                if cell_pci is not None and other_pci is not None and cell_pci == other_pci:
                    # Check if the cells are neighbors by looking at handovers
                    if 'Handover_Event' in df.columns:
                        # Look for handovers between these cells
                        handovers = df[(df['Handover_Event'] == True) & 
                                      (((df['CellID'] == cell_id) & (df['CellID'].shift(-1) == other_cell_id)) |
                                       ((df['CellID'] == other_cell_id) & (df['CellID'].shift(-1) == cell_id)))]
                        
                        if len(handovers) > 0:
                            parameter_mismatches.append({
                                'CellID': f"{cell_id} and {other_cell_id}",
                                'Parameter': 'PCI Conflict',
                                'Expected': 'Different PCIs',
                                'Observed': f"Both cells using PCI {cell_pci}",
                                'Samples': len(handovers),
                                'Description': f"Neighbor cells {cell_id} and {other_cell_id} have the same PCI {cell_pci}"
                            })
    
    return {
        'parameter_mismatches': pd.DataFrame(parameter_mismatches),
        'mismatch_count': len(parameter_mismatches)
    }

def analyze_qos_issues(df):
    """
    Analyze QoS issues in the drive test data.
    
    Args:
        df: DataFrame with drive test data
        
    Returns:
        dict: QoS analysis results
    """
    # Check if we have necessary columns
    qos_issues = {}
    
    # Track VoLTE MOS issues if we have MOS data
    if 'MOS' in df.columns:
        # Count samples with low MOS
        low_mos_threshold = 3.0  # Below 3.0 is considered poor voice quality
        low_mos_samples = df[df['MOS'] < low_mos_threshold]
        
        # Calculate percentage of samples with low MOS
        volte_mos_issues_pct = (len(low_mos_samples) / len(df)) * 100 if len(df) > 0 else 0
        
        # Identify areas with continuous low MOS
        df['Low_MOS'] = df['MOS'] < low_mos_threshold
        df['MOS_Issue_Group'] = (df['Low_MOS'] != df['Low_MOS'].shift(1)).cumsum()
        
        # Find continuous areas with MOS issues
        mos_issue_groups = df[df['Low_MOS']].groupby('MOS_Issue_Group')
        
        # Filter for significant MOS issue areas (at least 5 consecutive samples)
        significant_mos_issues = [group for name, group in mos_issue_groups if len(group) >= 5]
        
        # Create a DataFrame with MOS issue areas
        mos_issue_areas = []
        for i, issue_area in enumerate(significant_mos_issues):
            mos_issue_areas.append({
                'Area_ID': i + 1,
                'Start_Time': issue_area['Timestamp'].min(),
                'End_Time': issue_area['Timestamp'].max(),
                'Duration_Seconds': (issue_area['Timestamp'].max() - issue_area['Timestamp'].min()).total_seconds(),
                'Avg_MOS': issue_area['MOS'].mean(),
                'Samples': len(issue_area),
                'Latitude': issue_area['Latitude'].mean(),
                'Longitude': issue_area['Longitude'].mean(),
                'Avg_RSRP': issue_area['RSRP'].mean() if 'RSRP' in issue_area else None,
                'Avg_SINR': issue_area['SINR'].mean() if 'SINR' in issue_area else None,
                'Main_Cell_ID': issue_area['CellID'].mode()[0] if 'CellID' in issue_area and len(issue_area['CellID'].mode()) > 0 else 'Unknown'
            })
        
        qos_issues['volte_mos_issues_pct'] = volte_mos_issues_pct
        qos_issues['mos_issue_areas'] = pd.DataFrame(mos_issue_areas) if mos_issue_areas else pd.DataFrame()
    else:
        qos_issues['volte_mos_issues_pct'] = 0
        qos_issues['mos_issue_areas'] = pd.DataFrame()
    
    # Track QCI issues if we have QCI data
    if 'QCI' in df.columns:
        # Count QCI changes
        df['QCI_Change'] = df['QCI'] != df['QCI'].shift(1)
        qci_changes = df['QCI_Change'].sum()
        
        # Calculate percentage of samples with QCI changes
        qci_issues_pct = (qci_changes / len(df)) * 100 if len(df) > 0 else 0
        
        # Count downgrades to lower QCI
        if pd.api.types.is_numeric_dtype(df['QCI']):
            df['QCI_Downgrade'] = (df['QCI'] > df['QCI'].shift(1)) & df['QCI_Change']
            qci_downgrades = df['QCI_Downgrade'].sum()
        else:
            qci_downgrades = 0
        
        qos_issues['qci_issues_pct'] = qci_issues_pct
        qos_issues['qci_changes'] = qci_changes
        qos_issues['qci_downgrades'] = qci_downgrades
    else:
        qos_issues['qci_issues_pct'] = 0
        qos_issues['qci_changes'] = 0
        qos_issues['qci_downgrades'] = 0
    
    return qos_issues

def analyze_rf_metrics(df, rsrp_threshold=-105, rsrq_threshold=-15, sinr_threshold=5):
    """
    Analyze RF metrics in the drive test data.
    
    Args:
        df: DataFrame with drive test data
        rsrp_threshold: RSRP threshold in dBm for poor coverage
        rsrq_threshold: RSRQ threshold in dB for poor coverage
        sinr_threshold: SINR threshold in dB for interference detection
        
    Returns:
        dict: RF metrics analysis results
    """
    # Check if we have necessary columns
    required_columns = ['RSRP', 'RSRQ', 'SINR']
    
    # Initialize results
    results = {
        'rsrp_stats': {},
        'rsrq_stats': {},
        'sinr_stats': {},
        'coverage_issues_pct': 0,
        'interference_issues_pct': 0,
        'good_rf_pct': 0
    }
    
    # Calculate RSRP statistics if available
    if 'RSRP' in df.columns:
        df_rsrp = df.dropna(subset=['RSRP'])
        
        if len(df_rsrp) > 0:
            results['rsrp_stats'] = {
                'min': df_rsrp['RSRP'].min(),
                'max': df_rsrp['RSRP'].max(),
                'mean': df_rsrp['RSRP'].mean(),
                'median': df_rsrp['RSRP'].median(),
                'percentile_10': df_rsrp['RSRP'].quantile(0.1),
                'percentile_90': df_rsrp['RSRP'].quantile(0.9)
            }
            
            # Calculate coverage issues
            coverage_issues = (df_rsrp['RSRP'] < rsrp_threshold)
            results['coverage_issues_pct'] = (coverage_issues.sum() / len(df_rsrp)) * 100
    
    # Calculate RSRQ statistics if available
    if 'RSRQ' in df.columns:
        df_rsrq = df.dropna(subset=['RSRQ'])
        
        if len(df_rsrq) > 0:
            results['rsrq_stats'] = {
                'min': df_rsrq['RSRQ'].min(),
                'max': df_rsrq['RSRQ'].max(),
                'mean': df_rsrq['RSRQ'].mean(),
                'median': df_rsrq['RSRQ'].median(),
                'percentile_10': df_rsrq['RSRQ'].quantile(0.1),
                'percentile_90': df_rsrq['RSRQ'].quantile(0.9)
            }
            
            # Calculate interference issues from RSRQ
            if 'coverage_issues_pct' not in results or results['coverage_issues_pct'] == 0:
                interference_issues_rsrq = (df_rsrq['RSRQ'] < rsrq_threshold)
                results['interference_issues_pct'] = (interference_issues_rsrq.sum() / len(df_rsrq)) * 100
    
    # Calculate SINR statistics if available
    if 'SINR' in df.columns:
        df_sinr = df.dropna(subset=['SINR'])
        
        if len(df_sinr) > 0:
            results['sinr_stats'] = {
                'min': df_sinr['SINR'].min(),
                'max': df_sinr['SINR'].max(),
                'mean': df_sinr['SINR'].mean(),
                'median': df_sinr['SINR'].median(),
                'percentile_10': df_sinr['SINR'].quantile(0.1),
                'percentile_90': df_sinr['SINR'].quantile(0.9)
            }
            
            # Calculate interference issues from SINR
            interference_issues_sinr = (df_sinr['SINR'] < sinr_threshold)
            
            # Replace or average with RSRQ-based interference
            if 'interference_issues_pct' in results and results['interference_issues_pct'] > 0:
                results['interference_issues_pct'] = (results['interference_issues_pct'] + 
                                                     (interference_issues_sinr.sum() / len(df_sinr)) * 100) / 2
            else:
                results['interference_issues_pct'] = (interference_issues_sinr.sum() / len(df_sinr)) * 100
    
    # Calculate percentage of samples with good RF
    # Both RSRP and SINR are good
    if 'RSRP' in df.columns and 'SINR' in df.columns:
        df_both = df.dropna(subset=['RSRP', 'SINR'])
        
        if len(df_both) > 0:
            good_rf = (df_both['RSRP'] >= rsrp_threshold) & (df_both['SINR'] >= sinr_threshold)
            results['good_rf_pct'] = (good_rf.sum() / len(df_both)) * 100
    
    return results

def analyze_idle_connected_mode_failures(df):
    """
    Analyze idle and connected mode failures in the drive test data.
    
    Args:
        df: DataFrame with drive test data
        
    Returns:
        dict: Idle and connected mode failure analysis results
    """
    # Check if we have necessary columns
    required_event_keywords = ['rrc', 'idle', 'connected', 'setup', 'release', 'reestablish']
    
    # Check if we have any event-related columns
    if 'Event' not in df.columns:
        return {
            'rrc_setup_success_rate': 100.0,
            'rrc_reestablishment_rate': 0.0,
            'idle_mode_failures': 0,
            'connected_mode_failures': 0,
            'failure_details': pd.DataFrame()
        }
    
    # Find RRC setup attempts and successes
    rrc_setup_attempts = df[df['Event'].str.contains('rrc.*setup.*attempt|rrc.*connection.*request', 
                                                     case=False, regex=True, na=False)]
    
    rrc_setup_successes = df[df['Event'].str.contains('rrc.*setup.*complete|rrc.*connection.*setup.*complete', 
                                                       case=False, regex=True, na=False)]
    
    # Calculate RRC setup success rate
    rrc_setup_success_rate = (len(rrc_setup_successes) / len(rrc_setup_attempts) * 100) if len(rrc_setup_attempts) > 0 else 100.0
    
    # Find RRC reestablishment requests
    rrc_reestablishment_requests = df[df['Event'].str.contains('rrc.*reestablish', 
                                                              case=False, regex=True, na=False)]
    
    # Calculate RRC reestablishment rate
    total_rrc_events = len(rrc_setup_attempts) + len(rrc_setup_successes)
    rrc_reestablishment_rate = (len(rrc_reestablishment_requests) / total_rrc_events * 100) if total_rrc_events > 0 else 0.0
    
    # Find idle mode failures
    idle_mode_failures = df[df['Event'].str.contains('idle.*fail|paging.*fail|reselection.*fail', 
                                                     case=False, regex=True, na=False)]
    
    # Find connected mode failures
    connected_mode_failures = df[df['Event'].str.contains('connected.*fail|measurement.*fail|handover.*fail', 
                                                         case=False, regex=True, na=False)]
    
    # Combine failures for analysis
    all_failures = pd.concat([idle_mode_failures, connected_mode_failures])
    
    # Create failure details
    failure_details = []
    
    for idx, row in all_failures.iterrows():
        event = row['Event']
        detail = row['Event_Detail'] if 'Event_Detail' in row and pd.notna(row['Event_Detail']) else ''
        
        # Determine failure type
        if any(keyword in event.lower() for keyword in ['idle', 'paging', 'reselection']):
            failure_type = 'Idle Mode'
        else:
            failure_type = 'Connected Mode'
        
        # Determine failure category
        if 'handover' in event.lower():
            category = 'Handover Failure'
        elif 'measurement' in event.lower():
            category = 'Measurement Failure'
        elif 'rrc' in event.lower():
            category = 'RRC Failure'
        elif 'paging' in event.lower():
            category = 'Paging Failure'
        elif 'reselection' in event.lower():
            category = 'Reselection Failure'
        else:
            category = 'Other Failure'
        
        # Extract cause if available
        cause = 'Unknown'
        if 'cause' in detail.lower():
            cause_part = detail.lower().split('cause')[1]
            cause = cause_part.split(':')[1].strip() if ':' in cause_part else cause_part.strip()
        
        failure_details.append({
            'Timestamp': row['Timestamp'] if 'Timestamp' in row else idx,
            'Failure_Type': failure_type,
            'Failure_Category': category,
            'Event': event,
            'Detail': detail,
            'Cause': cause,
            'Cell_ID': row['CellID'] if 'CellID' in row else 'Unknown',
            'RSRP': row['RSRP'] if 'RSRP' in row else None,
            'SINR': row['SINR'] if 'SINR' in row else None
        })
    
    return {
        'rrc_setup_success_rate': rrc_setup_success_rate,
        'rrc_reestablishment_rate': rrc_reestablishment_rate,
        'idle_mode_failures': len(idle_mode_failures),
        'connected_mode_failures': len(connected_mode_failures),
        'failure_details': pd.DataFrame(failure_details) if failure_details else pd.DataFrame()
    }
