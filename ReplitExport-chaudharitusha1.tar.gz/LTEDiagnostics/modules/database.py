import os
import json
import pandas as pd
from datetime import datetime
from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Text, Boolean, ForeignKey, text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship

# Create base model class
Base = declarative_base()

# Define the models
class DriveTest(Base):
    """
    Model for storing drive test metadata
    """
    __tablename__ = 'drive_tests'
    
    id = Column(Integer, primary_key=True)
    filename = Column(String(255), nullable=False)
    file_format = Column(String(50), nullable=False)
    upload_date = Column(DateTime, default=datetime.now)
    record_count = Column(Integer)
    start_time = Column(DateTime)
    end_time = Column(DateTime)
    
    # Relationships
    metrics = relationship("TestMetrics", back_populates="drive_test", cascade="all, delete-orphan")
    reports = relationship("AnalysisReport", back_populates="drive_test", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<DriveTest(id={self.id}, filename='{self.filename}', upload_date='{self.upload_date}')>"

class TestMetrics(Base):
    """
    Model for storing aggregated metrics from the drive test
    """
    __tablename__ = 'test_metrics'
    
    id = Column(Integer, primary_key=True)
    drive_test_id = Column(Integer, ForeignKey('drive_tests.id'))
    avg_rsrp = Column(Float)
    avg_rsrq = Column(Float)
    avg_sinr = Column(Float)
    avg_throughput_dl = Column(Float)
    avg_throughput_ul = Column(Float)
    handover_count = Column(Integer)
    handover_success_rate = Column(Float)
    call_drop_rate = Column(Float)
    
    # Relationships
    drive_test = relationship("DriveTest", back_populates="metrics")
    
    def __repr__(self):
        return f"<TestMetrics(id={self.id}, drive_test_id={self.drive_test_id})>"

class AnalysisReport(Base):
    """
    Model for storing analysis reports
    """
    __tablename__ = 'analysis_reports'
    
    id = Column(Integer, primary_key=True)
    drive_test_id = Column(Integer, ForeignKey('drive_tests.id'))
    report_date = Column(DateTime, default=datetime.now)
    analysis_type = Column(String(100), nullable=False)
    threshold_values = Column(Text)  # JSON string of threshold values
    results = Column(Text)  # JSON string of analysis results
    
    # Relationships
    drive_test = relationship("DriveTest", back_populates="reports")
    root_causes = relationship("RootCause", back_populates="report", cascade="all, delete-orphan")
    
    def __repr__(self):
        return f"<AnalysisReport(id={self.id}, drive_test_id={self.drive_test_id}, analysis_type='{self.analysis_type}')>"

class RootCause(Base):
    """
    Model for storing root causes identified in analysis
    """
    __tablename__ = 'root_causes'
    
    id = Column(Integer, primary_key=True)
    report_id = Column(Integer, ForeignKey('analysis_reports.id'))
    issue_type = Column(String(100), nullable=False)
    severity = Column(String(50))
    description = Column(Text)
    recommendation = Column(Text)
    
    # Relationships
    report = relationship("AnalysisReport", back_populates="root_causes")
    
    def __repr__(self):
        return f"<RootCause(id={self.id}, issue_type='{self.issue_type}', severity='{self.severity}')>"

class ProblemArea(Base):
    """
    Model for storing identified problem areas
    """
    __tablename__ = 'problem_areas'
    
    id = Column(Integer, primary_key=True)
    drive_test_id = Column(Integer, ForeignKey('drive_tests.id'))
    problem_type = Column(String(100), nullable=False)  # Coverage, Interference, Handover, etc.
    latitude = Column(Float)
    longitude = Column(Float)
    start_time = Column(DateTime)
    end_time = Column(DateTime)
    avg_rsrp = Column(Float)
    avg_rsrq = Column(Float)
    avg_sinr = Column(Float)
    cell_id = Column(String(100))
    description = Column(Text)
    
    def __repr__(self):
        return f"<ProblemArea(id={self.id}, problem_type='{self.problem_type}')>"

# Database connection and session management
def get_database_url():
    """Get the database URL from environment variables"""
    db_url = os.environ.get('DATABASE_URL')
    if not db_url:
        # Fallback for local development
        db_url = "postgresql://localhost:5432/drivetest_analyzer"
    
    # Handle SSL requirements for cloud databases
    if 'neon.tech' in db_url or 'amazonaws.com' in db_url:
        if '?sslmode=' not in db_url:
            db_url += '?sslmode=require'
    
    return db_url

def init_db():
    """Initialize the database (create tables)"""
    try:
        engine = create_engine(
            get_database_url(),
            pool_pre_ping=True,
            pool_recycle=300,
            connect_args={"sslmode": "require"} if 'neon.tech' in get_database_url() else {}
        )
        # Test the connection first
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))
        
        Base.metadata.create_all(engine)
        return engine
    except Exception as e:
        print(f"Database initialization error: {e}")
        raise e

def get_session():
    """Get a database session"""
    try:
        engine = create_engine(
            get_database_url(),
            pool_pre_ping=True,
            pool_recycle=300,
            connect_args={"sslmode": "require"} if 'neon.tech' in get_database_url() else {}
        )
        Session = sessionmaker(bind=engine)
        return Session()
    except Exception as e:
        print(f"Database session error: {e}")
        raise e

# Database operations
def save_drive_test(filename, file_format, df):
    """
    Save drive test metadata to the database
    
    Args:
        filename: Name of the uploaded file
        file_format: Format of the file (CSV, Excel, etc.)
        df: DataFrame with the processed data
        
    Returns:
        The created DriveTest object
    """
    session = get_session()
    
    try:
        # Extract the time range
        start_time = df['Timestamp'].min() if 'Timestamp' in df.columns else None
        end_time = df['Timestamp'].max() if 'Timestamp' in df.columns else None
        
        # Create the drive test record
        drive_test = DriveTest(
            filename=filename,
            file_format=file_format,
            record_count=len(df),
            start_time=start_time,
            end_time=end_time
        )
        
        session.add(drive_test)
        session.flush()  # Flush to get the ID without committing
        
        # Calculate and save metrics
        avg_rsrp = df['RSRP'].mean() if 'RSRP' in df.columns else None
        avg_rsrq = df['RSRQ'].mean() if 'RSRQ' in df.columns else None
        avg_sinr = df['SINR'].mean() if 'SINR' in df.columns else None
        avg_throughput_dl = df['Throughput_DL'].mean() if 'Throughput_DL' in df.columns else None
        avg_throughput_ul = df['Throughput_UL'].mean() if 'Throughput_UL' in df.columns else None
        
        metrics = TestMetrics(
            drive_test_id=drive_test.id,
            avg_rsrp=avg_rsrp,
            avg_rsrq=avg_rsrq,
            avg_sinr=avg_sinr,
            avg_throughput_dl=avg_throughput_dl,
            avg_throughput_ul=avg_throughput_ul
        )
        
        session.add(metrics)
        session.commit()
        
        return drive_test
    
    except Exception as e:
        session.rollback()
        raise e
    
    finally:
        session.close()

def save_analysis_report(drive_test_id, analysis_type, thresholds, results, root_causes_list=None):
    """
    Save analysis report to the database
    
    Args:
        drive_test_id: ID of the drive test
        analysis_type: Type of analysis (Coverage, Interference, etc.)
        thresholds: Dictionary of threshold values
        results: Dictionary of analysis results
        root_causes_list: List of dictionaries with root cause data
        
    Returns:
        The created AnalysisReport object
    """
    session = get_session()
    
    try:
        # Create the report
        report = AnalysisReport(
            drive_test_id=drive_test_id,
            analysis_type=analysis_type,
            threshold_values=json.dumps(thresholds),
            results=json.dumps(results)
        )
        
        session.add(report)
        session.flush()  # Flush to get the ID without committing
        
        # Add root causes if provided
        if root_causes_list:
            for rc_data in root_causes_list:
                root_cause = RootCause(
                    report_id=report.id,
                    issue_type=rc_data.get('Issue', ''),
                    severity=rc_data.get('Severity', ''),
                    description=rc_data.get('Description', ''),
                    recommendation=rc_data.get('Recommendation', '')
                )
                session.add(root_cause)
        
        session.commit()
        return report
    
    except Exception as e:
        session.rollback()
        raise e
    
    finally:
        session.close()

def save_problem_areas(drive_test_id, problem_type, problem_areas_df):
    """
    Save problem areas to the database
    
    Args:
        drive_test_id: ID of the drive test
        problem_type: Type of problem (Coverage, Interference, etc.)
        problem_areas_df: DataFrame with problem areas data
        
    Returns:
        Count of saved problem areas
    """
    if problem_areas_df.empty:
        return 0
    
    session = get_session()
    count = 0
    
    try:
        for _, row in problem_areas_df.iterrows():
            problem_area = ProblemArea(
                drive_test_id=drive_test_id,
                problem_type=problem_type,
                latitude=row.get('Latitude') if 'Latitude' in row else None,
                longitude=row.get('Longitude') if 'Longitude' in row else None,
                start_time=row.get('Start_Time') if 'Start_Time' in row else None,
                end_time=row.get('End_Time') if 'End_Time' in row else None,
                avg_rsrp=row.get('Avg_RSRP') if 'Avg_RSRP' in row else None,
                avg_rsrq=row.get('Avg_RSRQ') if 'Avg_RSRQ' in row else None,
                avg_sinr=row.get('Avg_SINR') if 'Avg_SINR' in row else None,
                cell_id=row.get('Main_Cell_ID') if 'Main_Cell_ID' in row else None,
                description=f"Problem area {row.get('Area_ID', count+1)}"
            )
            session.add(problem_area)
            count += 1
        
        session.commit()
        return count
    
    except Exception as e:
        session.rollback()
        raise e
    
    finally:
        session.close()

def get_all_drive_tests():
    """
    Get all drive tests from the database
    
    Returns:
        List of DriveTest objects
    """
    session = get_session()
    try:
        return session.query(DriveTest).order_by(DriveTest.upload_date.desc()).all()
    finally:
        session.close()

def get_drive_test_by_id(drive_test_id):
    """
    Get a drive test by ID
    
    Args:
        drive_test_id: ID of the drive test
        
    Returns:
        DriveTest object
    """
    session = get_session()
    try:
        return session.query(DriveTest).filter(DriveTest.id == drive_test_id).first()
    finally:
        session.close()

def get_reports_for_drive_test(drive_test_id):
    """
    Get analysis reports for a drive test
    
    Args:
        drive_test_id: ID of the drive test
        
    Returns:
        List of AnalysisReport objects
    """
    session = get_session()
    try:
        return session.query(AnalysisReport).filter(
            AnalysisReport.drive_test_id == drive_test_id
        ).order_by(AnalysisReport.report_date.desc()).all()
    finally:
        session.close()

def get_problem_areas_for_drive_test(drive_test_id, problem_type=None):
    """
    Get problem areas for a drive test
    
    Args:
        drive_test_id: ID of the drive test
        problem_type: Optional type of problem to filter by
        
    Returns:
        List of ProblemArea objects
    """
    session = get_session()
    try:
        query = session.query(ProblemArea).filter(ProblemArea.drive_test_id == drive_test_id)
        if problem_type:
            query = query.filter(ProblemArea.problem_type == problem_type)
        return query.all()
    finally:
        session.close()

def delete_drive_test(drive_test_id):
    """
    Delete a drive test and all related data
    
    Args:
        drive_test_id: ID of the drive test
        
    Returns:
        True if successful, False otherwise
    """
    session = get_session()
    try:
        drive_test = session.query(DriveTest).filter(DriveTest.id == drive_test_id).first()
        if drive_test:
            session.delete(drive_test)
            session.commit()
            return True
        return False
    except Exception as e:
        session.rollback()
        return False
    finally:
        session.close()