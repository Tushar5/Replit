import pandas as pd
import numpy as np
import io
import os
import re
import xml.etree.ElementTree as ET
from datetime import datetime

def detect_file_format(uploaded_file):
    """
    Detect the format of the uploaded TEMS drive test log file.
    
    Args:
        uploaded_file: The uploaded file object
        
    Returns:
        str: Detected file format
    """
    # Get file extension
    file_extension = os.path.splitext(uploaded_file.name)[1].lower()
    
    if file_extension == '.csv':
        return 'CSV'
    elif file_extension in ['.xls', '.xlsx']:
        return 'Excel'
    elif file_extension == '.log':
        # Read first few lines to detect format
        uploaded_file.seek(0)
        sample_content = uploaded_file.read(1024).decode('utf-8', errors='ignore')
        uploaded_file.seek(0)  # Reset file pointer
        
        if '<TEMS' in sample_content or '<?xml' in sample_content:
            return 'TEMS XML'
        else:
            return 'TEMS Log'
    elif file_extension == '.txt':
        return 'Text'
    elif file_extension == '.trp':
        return 'TEMS TRP'
    else:
        return 'Unknown'

def process_tems_data(uploaded_file):
    """
    Process TEMS drive test log data from various formats.
    
    Args:
        uploaded_file: The uploaded file object
        
    Returns:
        pd.DataFrame: Processed data in a standardized format
    """
    file_format = detect_file_format(uploaded_file)
    
    if file_format == 'CSV':
        return process_csv_file(uploaded_file)
    elif file_format == 'Excel':
        return process_excel_file(uploaded_file)
    elif file_format == 'TEMS XML':
        return process_tems_xml(uploaded_file)
    elif file_format == 'TEMS Log':
        return process_tems_log(uploaded_file)
    elif file_format == 'TEMS TRP':
        return process_tems_trp(uploaded_file)
    elif file_format == 'Text':
        return process_text_file(uploaded_file)
    else:
        raise ValueError(f"Unsupported file format: {file_format}")

def process_csv_file(uploaded_file):
    """
    Process CSV format TEMS drive test log.
    
    Args:
        uploaded_file: The uploaded file object
        
    Returns:
        pd.DataFrame: Processed data
    """
    # Try to detect delimiter
    uploaded_file.seek(0)
    sample = uploaded_file.read(1024).decode('utf-8', errors='ignore')
    uploaded_file.seek(0)
    
    # Count common delimiters
    comma_count = sample.count(',')
    semicolon_count = sample.count(';')
    tab_count = sample.count('\t')
    
    # Determine most likely delimiter
    if comma_count >= semicolon_count and comma_count >= tab_count:
        delimiter = ','
    elif semicolon_count >= comma_count and semicolon_count >= tab_count:
        delimiter = ';'
    else:
        delimiter = '\t'
    
    # Read the CSV file
    df = pd.read_csv(uploaded_file, delimiter=delimiter, low_memory=False)
    
    # Standardize column names
    df = standardize_column_names(df)
    
    # Add derived metrics
    df = add_derived_metrics(df)
    
    return df

def process_excel_file(uploaded_file):
    """
    Process Excel format TEMS drive test log.
    
    Args:
        uploaded_file: The uploaded file object
        
    Returns:
        pd.DataFrame: Processed data
    """
    # Read the Excel file
    df = pd.read_excel(uploaded_file)
    
    # Standardize column names
    df = standardize_column_names(df)
    
    # Add derived metrics
    df = add_derived_metrics(df)
    
    return df

def process_tems_xml(uploaded_file):
    """
    Process TEMS XML format drive test log.
    
    Args:
        uploaded_file: The uploaded file object
        
    Returns:
        pd.DataFrame: Processed data
    """
    # Read XML content
    uploaded_file.seek(0)
    content = uploaded_file.read().decode('utf-8', errors='ignore')
    
    # Parse XML
    root = ET.fromstring(content)
    
    # Initialize lists to store data
    data = {
        'Timestamp': [],
        'Latitude': [],
        'Longitude': [],
        'PCI': [],
        'CellID': [],
        'EARFCN': [],
        'RSRP': [],
        'RSRQ': [],
        'SINR': [],
        'Throughput_DL': [],
        'Throughput_UL': [],
        'Event': [],
        'Event_Detail': []
    }
    
    # Extract relevant data from XML structure
    # This is a simplified example; actual XML parsing depends on TEMS XML format
    for event in root.findall('.//Event'):
        timestamp = event.get('timestamp', '')
        
        # Try to convert timestamp to datetime
        try:
            timestamp = datetime.strptime(timestamp, '%Y-%m-%d %H:%M:%S.%f')
        except (ValueError, TypeError):
            try:
                timestamp = datetime.strptime(timestamp, '%Y-%m-%d %H:%M:%S')
            except (ValueError, TypeError):
                timestamp = None
        
        lat = float(event.get('latitude', 0)) if event.get('latitude') else None
        lon = float(event.get('longitude', 0)) if event.get('longitude') else None
        
        # Extract cell information
        cell_info = event.find('CellInfo')
        if cell_info is not None:
            pci = int(cell_info.get('pci', 0)) if cell_info.get('pci') else None
            cell_id = cell_info.get('cellId', '')
            earfcn = int(cell_info.get('earfcn', 0)) if cell_info.get('earfcn') else None
        else:
            pci = None
            cell_id = ''
            earfcn = None
        
        # Extract RF metrics
        rf_metrics = event.find('RFMetrics')
        if rf_metrics is not None:
            rsrp = float(rf_metrics.get('rsrp', 0)) if rf_metrics.get('rsrp') else None
            rsrq = float(rf_metrics.get('rsrq', 0)) if rf_metrics.get('rsrq') else None
            sinr = float(rf_metrics.get('sinr', 0)) if rf_metrics.get('sinr') else None
        else:
            rsrp = None
            rsrq = None
            sinr = None
        
        # Extract throughput data
        throughput = event.find('Throughput')
        if throughput is not None:
            dl_throughput = float(throughput.get('dl', 0)) if throughput.get('dl') else None
            ul_throughput = float(throughput.get('ul', 0)) if throughput.get('ul') else None
        else:
            dl_throughput = None
            ul_throughput = None
        
        # Extract event data
        event_type = event.get('type', '')
        event_detail = event.get('detail', '')
        
        # Add data to lists
        data['Timestamp'].append(timestamp)
        data['Latitude'].append(lat)
        data['Longitude'].append(lon)
        data['PCI'].append(pci)
        data['CellID'].append(cell_id)
        data['EARFCN'].append(earfcn)
        data['RSRP'].append(rsrp)
        data['RSRQ'].append(rsrq)
        data['SINR'].append(sinr)
        data['Throughput_DL'].append(dl_throughput)
        data['Throughput_UL'].append(ul_throughput)
        data['Event'].append(event_type)
        data['Event_Detail'].append(event_detail)
    
    # Create DataFrame
    df = pd.DataFrame(data)
    
    # Add derived metrics
    df = add_derived_metrics(df)
    
    return df

def process_tems_log(uploaded_file):
    """
    Process TEMS log format drive test log.
    
    Args:
        uploaded_file: The uploaded file object
        
    Returns:
        pd.DataFrame: Processed data
    """
    # Read log content
    uploaded_file.seek(0)
    content = uploaded_file.read().decode('utf-8', errors='ignore')
    lines = content.split('\n')
    
    # Initialize lists to store data
    data = {
        'Timestamp': [],
        'Latitude': [],
        'Longitude': [],
        'PCI': [],
        'CellID': [],
        'EARFCN': [],
        'RSRP': [],
        'RSRQ': [],
        'SINR': [],
        'Throughput_DL': [],
        'Throughput_UL': [],
        'Event': [],
        'Event_Detail': []
    }
    
    # Define regex patterns for extracting data
    timestamp_pattern = r'(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}.\d+)'
    location_pattern = r'LAT:([-]?\d+\.\d+)\s+LON:([-]?\d+\.\d+)'
    cell_pattern = r'PCI:(\d+)\s+CellID:(\w+)\s+EARFCN:(\d+)'
    rf_pattern = r'RSRP:([-]?\d+\.\d+)\s+RSRQ:([-]?\d+\.\d+)\s+SINR:([-]?\d+\.\d+)'
    throughput_pattern = r'DL:(\d+\.\d+)\s+UL:(\d+\.\d+)'
    event_pattern = r'EVENT:(\w+)\s+DETAIL:(.+)'
    
    timestamp = None
    latitude = None
    longitude = None
    pci = None
    cell_id = None
    earfcn = None
    rsrp = None
    rsrq = None
    sinr = None
    throughput_dl = None
    throughput_ul = None
    event = None
    event_detail = None
    
    # Process each line
    for line in lines:
        line = line.strip()
        if not line:
            continue
        
        # Extract timestamp
        ts_match = re.search(timestamp_pattern, line)
        if ts_match:
            # If we have a new timestamp and already have data, add the previous record
            if timestamp is not None and latitude is not None and longitude is not None:
                data['Timestamp'].append(timestamp)
                data['Latitude'].append(latitude)
                data['Longitude'].append(longitude)
                data['PCI'].append(pci)
                data['CellID'].append(cell_id)
                data['EARFCN'].append(earfcn)
                data['RSRP'].append(rsrp)
                data['RSRQ'].append(rsrq)
                data['SINR'].append(sinr)
                data['Throughput_DL'].append(throughput_dl)
                data['Throughput_UL'].append(throughput_ul)
                data['Event'].append(event)
                data['Event_Detail'].append(event_detail)
            
            # Parse new timestamp
            timestamp_str = ts_match.group(1)
            try:
                timestamp = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S.%f')
            except ValueError:
                try:
                    timestamp = datetime.strptime(timestamp_str, '%Y-%m-%d %H:%M:%S')
                except ValueError:
                    timestamp = None
        
        # Extract location
        loc_match = re.search(location_pattern, line)
        if loc_match:
            latitude = float(loc_match.group(1))
            longitude = float(loc_match.group(2))
        
        # Extract cell info
        cell_match = re.search(cell_pattern, line)
        if cell_match:
            pci = int(cell_match.group(1))
            cell_id = cell_match.group(2)
            earfcn = int(cell_match.group(3))
        
        # Extract RF metrics
        rf_match = re.search(rf_pattern, line)
        if rf_match:
            rsrp = float(rf_match.group(1))
            rsrq = float(rf_match.group(2))
            sinr = float(rf_match.group(3))
        
        # Extract throughput
        tp_match = re.search(throughput_pattern, line)
        if tp_match:
            throughput_dl = float(tp_match.group(1))
            throughput_ul = float(tp_match.group(2))
        
        # Extract event
        event_match = re.search(event_pattern, line)
        if event_match:
            event = event_match.group(1)
            event_detail = event_match.group(2)
    
    # Add the last record if we have data
    if timestamp is not None and latitude is not None and longitude is not None:
        data['Timestamp'].append(timestamp)
        data['Latitude'].append(latitude)
        data['Longitude'].append(longitude)
        data['PCI'].append(pci)
        data['CellID'].append(cell_id)
        data['EARFCN'].append(earfcn)
        data['RSRP'].append(rsrp)
        data['RSRQ'].append(rsrq)
        data['SINR'].append(sinr)
        data['Throughput_DL'].append(throughput_dl)
        data['Throughput_UL'].append(throughput_ul)
        data['Event'].append(event)
        data['Event_Detail'].append(event_detail)
    
    # Create DataFrame
    df = pd.DataFrame(data)
    
    # Add derived metrics
    df = add_derived_metrics(df)
    
    return df

def process_text_file(uploaded_file):
    """
    Process text format TEMS drive test log.
    
    Args:
        uploaded_file: The uploaded file object
        
    Returns:
        pd.DataFrame: Processed data
    """
    # Try to read the text file as a CSV
    try:
        return process_csv_file(uploaded_file)
    except:
        # If CSV parsing fails, try to parse as TEMS log
        try:
            return process_tems_log(uploaded_file)
        except:
            # If both fail, raise an error
            raise ValueError("Unable to parse the text file format")
            
def process_tems_trp(uploaded_file):
    """
    Process TEMS TRP format drive test log.
    
    Args:
        uploaded_file: The uploaded file object
        
    Returns:
        pd.DataFrame: Processed data
    """
    # TRP files are binary format specific to TEMS
    # We'll try to parse it as a binary file and extract the data we need
    
    # Initialize lists to store data
    data = {
        'Timestamp': [],
        'Latitude': [],
        'Longitude': [],
        'PCI': [],
        'CellID': [],
        'EARFCN': [],
        'RSRP': [],
        'RSRQ': [],
        'SINR': [],
        'Throughput_DL': [],
        'Throughput_UL': [],
        'Event': [],
        'Event_Detail': []
    }
    
    # Read TRP content as binary
    uploaded_file.seek(0)
    binary_content = uploaded_file.read()
    
    # Try to find patterns in the binary data that might indicate data fields
    # This is a simplified approach as we don't have full specs of TRP format
    
    # Convert binary to hex string for easier pattern matching
    hex_content = binary_content.hex()
    
    # Look for patterns that might represent timestamps
    timestamp_base = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    
    # Look for patterns that might represent GPS coordinates
    # Typical GPS patterns in binary files might be IEEE-754 floating point numbers
    
    # Look for LTE cell information patterns
    # PCI values are typically 0-503, EARFCN values have specific ranges
    
    # Look for RF measurement patterns
    # RSRP values typically range from -140 to -70 dBm
    # RSRQ values typically range from -20 to 0 dB
    # SINR values typically range from -10 to 30 dB
    
    # Since TRP format is proprietary and requires TEMS-specific libraries for proper parsing,
    # we'll create a sample dataset with warning
    
    # Create a placeholder timestamp sequence
    timestamp_sequence = [timestamp_base + pd.Timedelta(seconds=i) for i in range(100)]
    
    # Fill in the data dictionary with empty or placeholder values
    data['Timestamp'] = timestamp_sequence
    data['Latitude'] = [None] * 100
    data['Longitude'] = [None] * 100
    data['PCI'] = [None] * 100
    data['CellID'] = [''] * 100
    data['EARFCN'] = [None] * 100
    data['RSRP'] = [None] * 100
    data['RSRQ'] = [None] * 100
    data['SINR'] = [None] * 100
    data['Throughput_DL'] = [None] * 100
    data['Throughput_UL'] = [None] * 100
    data['Event'] = ['TRP_FILE_IMPORTED'] * 100
    data['Event_Detail'] = ['TRP file format detected - custom parser required'] * 100
    
    # Create DataFrame
    df = pd.DataFrame(data)
    
    # Since this is just a placeholder, we'll add a message to the first row
    special_message = """
    TRP file format is proprietary to TEMS and requires specific libraries for parsing.
    The data shown is just a placeholder. To properly analyze TRP files, consider:
    1. Exporting to CSV/Excel from TEMS software
    2. Using TEMS API for data extraction
    3. Converting to a standard format with TEMS tools
    """
    
    df.at[0, 'Event_Detail'] = special_message
    
    # Add derived metrics
    df = add_derived_metrics(df)
    
    return df

def standardize_column_names(df):
    """
    Standardize column names to a common format.
    
    Args:
        df: DataFrame with original column names
        
    Returns:
        DataFrame with standardized column names
    """
    # Create a mapping of possible column names to standard names
    column_mapping = {
        # Timestamp columns
        'time': 'Timestamp',
        'timestamp': 'Timestamp',
        'date': 'Timestamp',
        'datetime': 'Timestamp',
        'time_stamp': 'Timestamp',
        
        # Location columns
        'latitude': 'Latitude',
        'lat': 'Latitude',
        'longitude': 'Longitude',
        'lon': 'Longitude',
        'long': 'Longitude',
        
        # Cell identity columns
        'pci': 'PCI',
        'physicalcellid': 'PCI',
        'physical_cell_id': 'PCI',
        'cellid': 'CellID',
        'cell_id': 'CellID',
        'cell': 'CellID',
        'eci': 'CellID',
        'earfcn': 'EARFCN',
        'earfcndl': 'EARFCN',
        'dl_earfcn': 'EARFCN',
        'freq': 'EARFCN',
        'frequency': 'EARFCN',
        
        # RF metrics columns
        'rsrp': 'RSRP',
        'lte_rsrp': 'RSRP',
        'rsrpdecibm': 'RSRP',
        'rsrp_dbm': 'RSRP',
        'rsrq': 'RSRQ',
        'lte_rsrq': 'RSRQ',
        'rsrqdecib': 'RSRQ',
        'rsrq_db': 'RSRQ',
        'sinr': 'SINR',
        'lte_sinr': 'SINR',
        'sinrdecib': 'SINR',
        'sinr_db': 'SINR',
        
        # Throughput columns
        'dl_throughput': 'Throughput_DL',
        'dl_tp': 'Throughput_DL',
        'dltp': 'Throughput_DL',
        'throughput_dl': 'Throughput_DL',
        'download': 'Throughput_DL',
        'ul_throughput': 'Throughput_UL',
        'ul_tp': 'Throughput_UL',
        'ultp': 'Throughput_UL',
        'throughput_ul': 'Throughput_UL',
        'upload': 'Throughput_UL',
        
        # Event columns
        'event': 'Event',
        'event_type': 'Event',
        'eventtype': 'Event',
        'event_detail': 'Event_Detail',
        'detail': 'Event_Detail',
        'eventdetail': 'Event_Detail',
        'description': 'Event_Detail',
        
        # Call-related columns
        'call_state': 'Call_State',
        'callstate': 'Call_State',
        'call_status': 'Call_State',
        'call_type': 'Call_Type',
        'calltype': 'Call_Type',
        
        # VoLTE-specific columns
        'mos': 'MOS',
        'volte_mos': 'MOS',
        'volte_quality': 'MOS',
        'speech_quality': 'MOS',
        
        # RRC state columns
        'rrc_state': 'RRC_State',
        'rrcstate': 'RRC_State',
        'rrc': 'RRC_State',
        
        # Bearer columns
        'qci': 'QCI',
        'bearer_qci': 'QCI',
        'bearer_type': 'Bearer_Type',
        'bearertype': 'Bearer_Type'
    }
    
    # Create a new mapping for the actual columns in the DataFrame
    new_columns = {}
    for col in df.columns:
        col_lower = col.lower().replace(' ', '_')
        if col_lower in column_mapping:
            new_columns[col] = column_mapping[col_lower]
        else:
            new_columns[col] = col
    
    # Rename the columns
    df = df.rename(columns=new_columns)
    
    return df

def add_derived_metrics(df):
    """
    Add derived metrics based on available data.
    
    Args:
        df: DataFrame with base metrics
        
    Returns:
        DataFrame with added derived metrics
    """
    # Add RF quality category based on RSRP
    if 'RSRP' in df.columns:
        df['RSRP_Category'] = pd.cut(
            df['RSRP'],
            bins=[-float('inf'), -110, -100, -90, -80, float('inf')],
            labels=['Very Poor', 'Poor', 'Fair', 'Good', 'Excellent']
        )
    
    # Add interference category based on SINR
    if 'SINR' in df.columns:
        df['SINR_Category'] = pd.cut(
            df['SINR'],
            bins=[-float('inf'), 0, 5, 10, 15, float('inf')],
            labels=['Very High', 'High', 'Medium', 'Low', 'Very Low']
        )
    
    # Detect handover events
    if 'PCI' in df.columns:
        df['Handover_Event'] = (df['PCI'] != df['PCI'].shift(1)) & (~df['PCI'].isna()) & (~df['PCI'].shift(1).isna())
    
    # Detect cell changes
    if 'CellID' in df.columns:
        df['Cell_Change'] = (df['CellID'] != df['CellID'].shift(1)) & (~df['CellID'].isna()) & (~df['CellID'].shift(1).isna())
    
    # Convert throughput to Mbps if it appears to be in kbps
    if 'Throughput_DL' in df.columns:
        # Check if values are likely in kbps (most values > 1000)
        if df['Throughput_DL'].median() > 1000:
            df['Throughput_DL'] = df['Throughput_DL'] / 1000  # Convert to Mbps
    
    if 'Throughput_UL' in df.columns:
        # Check if values are likely in kbps (most values > 1000)
        if df['Throughput_UL'].median() > 1000:
            df['Throughput_UL'] = df['Throughput_UL'] / 1000  # Convert to Mbps
    
    # Add coverage quality metric (combining RSRP and RSRQ)
    if 'RSRP' in df.columns and 'RSRQ' in df.columns:
        # Normalize RSRP to 0-1 scale (-140 to -70 dBm range)
        rsrp_norm = (df['RSRP'] - (-140)) / ((-70) - (-140))
        rsrp_norm = rsrp_norm.clip(0, 1)
        
        # Normalize RSRQ to 0-1 scale (-20 to 0 dB range)
        rsrq_norm = (df['RSRQ'] - (-20)) / (0 - (-20))
        rsrq_norm = rsrq_norm.clip(0, 1)
        
        # Combined metric (70% RSRP, 30% RSRQ)
        df['Coverage_Quality'] = 0.7 * rsrp_norm + 0.3 * rsrq_norm
        
        # Categorize
        df['Coverage_Category'] = pd.cut(
            df['Coverage_Quality'],
            bins=[0, 0.2, 0.4, 0.6, 0.8, 1.0],
            labels=['Very Poor', 'Poor', 'Fair', 'Good', 'Excellent']
        )
    
    return df
